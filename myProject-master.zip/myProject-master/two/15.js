//简单的解压缩算法  ？

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
rl.on("line", (line) => {
  console.log(getResult(line));
});
 
function getResult(str) {
  const stack = [];
  const idxs = [];
  const repeat = [];
 
  str += " ";
 
  for (let c of str) {
    if (/\d/.test(c)) {
      repeat.push(c);
      continue;
    }
 
    // 如果出现A13,或者{ABC}99这种情况，我们需要把多位数解析出来
    if (repeat.length > 0) {
      const n = parseInt(repeat.join(""));
      repeat.length = 0;
      const top = stack.pop();
      if (top === "}") {
        const frag = stack.splice(idxs.pop()).slice(1).join("");
        stack.push(...new Array(n).fill(frag).join(""));
      } else {
        stack.push(...new Array(n).fill(top));
      }
    }
 
    if (c === "{") {
      idxs.push(stack.length);
    }
 
    stack.push(c);
  }
 
  return stack.join("").trim();
}