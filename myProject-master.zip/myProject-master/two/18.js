//基站维护工程师 100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
let n;
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 1) {
    n = lines[0] - 0;
  }
 
  if (n && lines.length === n + 1) {
    lines.shift();
    const matrix = lines.map((line) => line.split(" ").map(Number));
    console.log(getResult(matrix, n));
    lines.length = 0;
  }
});
 
function getResult(matrix, n) {
  const ans = { val: Infinity };
  dfs(n, [], [], ans, matrix);
 
  return ans.val;
}
 
function dfs(n, used, path, ans, matrix) {
  if (path.length === n - 1) {
    let dis = matrix[0][path[0]];
    path.reduce((p, c) => {
      dis += matrix[p][c];
      return c;
    });
    dis += matrix[path.at(-1)][0];
    ans.val = Math.min(ans.val, dis);
    return;
  }
 
  for (let i = 1; i < n; i++) {
    if (!used[i]) {
      path.push(i);
      used[i] = true;
      dfs(n, used, path, ans, matrix);
      used[i] = false;
      path.pop();
    }
  }
}