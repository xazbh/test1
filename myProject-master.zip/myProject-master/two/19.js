//最差产品奖  100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 2) {
    const m = lines[0] - 0;
    const arr = lines[1].split(",").map(Number);
    console.log(getResult(arr, m));
    lines.length = 0;
  }
});
 
function getResult(arr, m) {
  const ans = [];
  for (let i = 0; i <= arr.length - m; i++) {
    ans.push(Math.min(...arr.slice(i, i + m)));
  }
  return ans.join(",");
}