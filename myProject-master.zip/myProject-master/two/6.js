//连接器问题  区间连接器 88%+

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 2) {
    const ranges = JSON.parse(`[${lines[0]}]`);
    const connects = JSON.parse(lines[1]);
 
    console.log(getResult(ranges, connects));
    lines.length = 0;
  }
});
 
function getResult(ranges, connects) {
  ranges.sort((a, b) => a[0] - b[0]);
 
  const mergeRanges = [ranges.shift()];
  const diffs = [];
 
  for (let range of ranges) {
    const [s1, e1] = mergeRanges.at(-1);
    const [s2, e2] = range;
 
    if (s2 <= e1) {
      mergeRanges.pop();
      mergeRanges.push([s1, Math.max(e1, e2)]);
    } else {
      diffs.push(s2 - e1);
      mergeRanges.push(range);
    }
  }
 
  diffs.sort((a, b) => b - a);
  connects.sort((a, b) => b - a);
 
  while (connects.length && diffs.length) {
    if (connects.pop() >= diffs.at(-1)) {
      diffs.pop();
    }
  }
 
  return diffs.length + 1;
}