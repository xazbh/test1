//士兵过河  ？

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 3) {
    const N = lines[0] - 0;
    const T = lines[1] - 0;
    const times = lines[2].split(" ").map(Number);
    console.log(getResult(N, T, times));
    lines.length = 0;
  }
});
 
/**
 *
 * @param {*} N 士兵数
 * @param {*} T 过河时间上限
 * @param {*} times 数组，元素表示每个士兵的过河时长
 */
function getResult(N, T, times) {
  times.sort((a, b) => a - b);
 
  const dp = new Array(N);
 
  for (let i = 0; i < N; i++) {
    if (i >= 2) {
      dp[i] = Math.min(
        dp[i - 1] + times[0] + getMax(times[0], times[i]),
        dp[i - 2] +
          times[0] +
          getMax(times[i - 1], times[i]) +
          times[1] +
          getMax(times[0], times[1])
      );
    } else if (i === 1) {
      dp[1] = getMax(times[0], times[1]);
    } else {
      dp[0] = times[0];
    }
 
    if (dp[i] > T) return `${i} ${dp[i - 1] ?? 0}`;
  }
 
  return `${N} ${dp[N - 1]}`;
}
 
// 输入需要保证t1 <= t2
function getMax(t1, t2) {
  if (t1 * 10 < t2) {
    return t1 * 10;
  }
  return t2;
}