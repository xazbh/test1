//Excel单元格数值统计   ?

/* JavaScript Node ACM模式 控制台输入获取 */
const { get } = require("http");
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
 
let table, rows, cols, start, end;
 
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 1) {
    [rows, cols] = lines[0].split(" ").map(Number);
  }
 
  if (rows && lines.length === rows + 2) {
    lines.shift();
    [start, end] = lines.pop().split(":");
    table = lines.map((line) => line.split(" "));
    console.log(getResult());
    lines.length = 0;
  }
});
 
function getResult() {
  const [r1, c1] = getPos(start);
  const [r2, c2] = getPos(end);
 
  let ans = 0;
  for (let i = r1; i <= r2; i++) {
    for (let j = c1; j <= c2; j++) {
      ans += getCellVal(table[i][j]);
    }
  }
 
  return ans;
}
 
// 判断一个内容是否为单元格坐标
function isPos(s) {
  return s[0] <= "Z" && s[0] >= "A";
}
 
// 解析单元格坐标  为  矩阵坐标
function getPos(pos) {
  const c = pos[0].charCodeAt() - 65;
  const r = pos.slice(1) - 1;
  return [r, c];
}
 
// 获取矩阵对应坐标的值，并且更新矩阵对应单元格的内容
function getPosVal(pos) {
  const [r, c] = pos;
  table[r][c] = getCellVal(table[r][c]);
  return table[r][c];
}
 
// 双目运算
function operate(ops, isAdd) {
  let op1, op2;
 
  if (isPos(ops[0])) {
    // 如果操作数1是单元格
    op1 = getPosVal(getPos(ops[0]));
  } else {
    // 如果操作数1是数字
    op1 = parseInt(ops[0]);
  }
 
  if (isPos(ops[1])) {
    // 如果操作数2是单元格
    op2 = getPosVal(getPos(ops[1]));
  } else {
    // 如果操作数2是数字
    op2 = parseInt(ops[1]);
  }
 
  if (isAdd) {
    // 加法运算
    return op1 + op2;
  } else {
    // 减法运算
    return op1 - op2;
  }
}
 
// 获取单元格的值
function getCellVal(cell) {
  /*
   * 单元格内容cell如果以'='开头，则必然是公式
   * */
  if (cell[0] == "=") {
    // fn是公式内容
    const fn = cell.slice(1);
 
    // 如果公式内容fn包含“+”，则可能是两个单元格的双目运算，也可能是单元格和数字的双目运算
    if (fn.indexOf("+") != -1) {
      return operate(fn.split("+"), true);
    } else if (fn.indexOf("-") != -1) {
      // 如果公式内容fn包含“-”，则可能是两个单元格的双目运算，也可能是单元格和数字的双目运算
      return operate(fn.split("-"), false);
    } else {
      // 如果公式内容fn不包含“+”和“-”，则必然等于某单元格的值，例如=B12
      return getPosVal(getPos(fn));
    }
  } else {
    /*
     * 单元格内容cell如果不以'='开头，则必然是数字，且是非负正数
     * */
    return parseInt(cell);
  }
}