//计算网络信号 网络强度   100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 3) {
    const [m, n] = lines[0].split(" ").map(Number);
    const arr = lines[1].split(" ").map(Number);
    const pos = lines[2].split(" ").map(Number);
    console.log(getResult(arr, m, n, pos));
    lines.length = 0;
  }
});
 
function getResult(arr, m, n, pos) {
  let queue = [];
 
  for (let i = 0; i < m; i++) {
    for (let j = 0; j < n; j++) {
      if (arr[i * n + j] > 0) {
        queue.push([i, j]);
        break;
      }
    }
  }
 
  // 上下左右偏移量
  const offset = [
    [-1, 0],
    [1, 0],
    [0, -1],
    [0, 1],
  ];
 
  while (queue.length) {
    const newQueue = []; // 此时不使用queue.shift操作，因为此步操每次都需要O(n)时间，无法应对大数量级情况
 
    for (const [i, j] of queue) {
      const x = arr[i * n + j] - 1;
 
      if (x === 0) break;
 
      for (let [offsetX, offsetY] of offset) {
        const newI = i + offsetX;
        const newJ = j + offsetY;
 
        if (
          newI >= 0 &&
          newI < m &&
          newJ >= 0 &&
          newJ < n &&
          arr[newI * n + newJ] === 0
        ) {
          arr[newI * n + newJ] = x;
          newQueue.push([newI, newJ]);
        }
      }
    }
 
    queue = newQueue;
  }
 
  const [tarI, tarJ] = pos;
  return arr[tarI * n + tarJ];
}