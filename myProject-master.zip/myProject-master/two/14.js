//二进制差异数   100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 2) {
    const arr = lines[1].split(" ").map(Number);
    console.log(getResult(arr));
    lines.length = 0;
  }
});
 
function getResult(arr) {
  // highBit是一个数组，由于题目说给定的A[i]取值小于2^30，因此我们可以定义一个30长度的数组，其元素含义是，比如highBit[i]代表最高位1处于第i位的数的个数
  // let highBit = new Array(30).fill(0);
  let highBit = new Array(60).fill(0); // 经网友反馈这里长度定义为60得100%通过率
  for (let a of arr) {
    const bin = Number(a).toString(2);
    const len = bin.length; // 数的二进制形式字符串（无前导0）的长度，就是该数二进制最高位1所处位数
    // 将“0”和“1”区别开来
    if (bin == "0") {
      highBit[0]++;
    } else {
      highBit[len]++;
    }
  }
 
  // 排除统计个数为0的情况
  highBit = highBit.filter((d) => d);
 
  let ans = 0;
  for (let i = 0; i < highBit.length; i++) {
    for (let j = i + 1; j < highBit.length; j++) {
      ans += highBit[i] * highBit[j];
    }
  }
 
  return ans;
}