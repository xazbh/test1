//数字加减游戏  100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
rl.on("line", (line) => {
  const [s, t, a, b] = line.split(" ").map(Number);
  console.log(getResult(s, t, a, b));
});
 
function getResult(s, t, a, b) {
  let x = 0;
  let diff = t - s;
  while (true) {
    if (
      Number.isInteger((diff - a * x) / b) ||
      Number.isInteger((diff + a * x) / b)
    ) {
      return Math.abs(x);
    }
 
    x++;
  }
}