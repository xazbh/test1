//探索地块建立   预计100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
let n, m, c, k;
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 1) {
    [n, m, c, k] = lines[0].split(" ").map(Number);
  }
 
  if (n && lines.length === n + 1) {
    const matrix = lines.slice(1).map((line) => line.split(" ").map(Number));
 
    console.log(getResult(matrix, n, m, c, k));
 
    lines.length = 0;
  }
});
 
/**
 *
 * @param {*} matrix n*m的地块
 * @param {*} n 地块行数
 * @param {*} m 地块列数
 * @param {*} c 正方形的发电站边长为c
 * @param {*} k 目标电量k
 */
function getResult(matrix, n, m, c, k) {
  const preSum = new Array(n + 1).fill(0).map(() => new Array(m + 1).fill(0));
 
  for (let i = 1; i <= n; i++) {
    for (let j = 1; j <= m; j++) {
      preSum[i][j] =
        preSum[i - 1][j] +
        preSum[i][j - 1] -
        preSum[i - 1][j - 1] +
        matrix[i - 1][j - 1];
    }
  }
 
  let ans = 0;
 
  for (let i = c; i <= n; i++) {
    for (let j = c; j <= m; j++) {
      const square =
        preSum[i][j] -
        (preSum[i - c][j] + preSum[i][j - c]) +
        preSum[i - c][j - c];
 
      if (square >= k) ans++;
    }
  }
 
  return ans;
}