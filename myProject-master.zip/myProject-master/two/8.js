//最大平分数组   预计95%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 2) {
    const m = lines[0] - 0;
    const arr = lines[1].split(" ").map(Number);
 
    console.log(getResutlt(m, arr));
 
    lines.length = 0;
  }
});
 
function getResutlt(m, arr) {
  const sum = arr.sort((a, b) => b - a).reduce((p, c) => p + c);
 
  let maxCount = m;
 
  while (maxCount >= 1) {
    if (canPartition([...arr], sum, maxCount)) {
      return maxCount;
    } else {
      maxCount--;
    }
  }
}
 
function canPartition(arr, sum, maxCount) {
  if (sum % maxCount) return false;
 
  const subSum = sum / maxCount;
 
  if (subSum < arr[0]) return false;
 
  while (arr[0] === subSum) {
    arr.shift();
    maxCount--;
  }
 
  const buckets = new Array(maxCount).fill(0);
 
  return partition(0, arr, subSum, buckets);
}
 
function partition(start, arr, subSum, buckets) {
  if (start === arr.length) return true;
 
  const select = arr[start];
 
  for (let i = 0; i < buckets.length; i++) {
    if (i > 0 && buckets[i] === buckets[i - 1]) continue;
 
    if (buckets[i] + select <= subSum) {
      buckets[i] += select;
      if (partition(start + 1, arr, subSum, buckets)) return true;
      buckets[i] -= select;
    }
  }
 
  return false;
}