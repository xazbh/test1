//区间交叠问题  最少数量线段覆盖  100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
let n;
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 1) {
    n = lines[0] - 0;
  }
 
  if (n && lines.length === n + 1) {
    lines.shift();
    const ranges = lines.map((line) => line.split(",").map(Number));
    console.log(getResult(ranges, n));
 
    lines.length = 0;
  }
});
 
function getResult(ranges, n) {
  ranges.sort((a, b) => a[0] - b[0]);
 
  const stack = [ranges[0]];
 
  for (let i = 1; i < ranges.length; i++) {
    const range = ranges[i];
 
    while (true) {
      if (stack.length == 0) {
        stack.push(range);
        break;
      }
 
      const [s0, e0] = stack.at(-1);
      const [s1, e1] = range;
 
      if (s1 <= s0) {
        if (e1 <= s0) {
          break;
        } else if (e1 < e0) {
          break;
        } else {
          stack.pop();
        }
      } else if (s1 < e0) {
        if (e1 <= e0) {
          break;
        } else {
          stack.push([e0, e1]);
          break;
        }
      } else {
        stack.push(range);
        break;
      }
    }
  }
 
  //console.log(stack);
 
  return stack.length;
}