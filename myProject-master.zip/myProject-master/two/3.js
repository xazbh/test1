//最大化控制资源成本   预计100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
let n;
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 1) {
    n = lines[0] - 0;
  }
 
  if (n && lines.length === n + 1) {
    const ranges = lines.slice(1).map((line) => line.split(" ").map(Number));
    console.log(getResult(ranges));
    lines.length = 0;
  }
});
 
function getResult(ranges) {
  ranges.sort((a, b) => a[0] - b[0]);
  const end = new PriorityQueue((a, b) => b[0] - a[0]);
 
  let max = 0;
  let sum = 0;
  for (let range of ranges) {
    const [s, e, p] = range;
 
    while (end.size()) {
      const top = end.peek();
 
      if (top[0] <= s) {
        const poll = end.shift();
        sum -= poll[1];
      } else {
        break;
      }
    }
 
    end.push([e, p]);
    sum += p;
 
    if (sum > max) {
      max = sum;
    }
  }
 
  return max;
}
 
class PriorityQueue {
  constructor(cpr) {
    this.queue = [];
    this.cpr = cpr;
  }
 
  swap(a, b) {
    const tmp = this.queue[a];
    this.queue[a] = this.queue[b];
    this.queue[b] = tmp;
  }
 
  // 上浮
  swim() {
    let c = this.queue.length - 1;
 
    while (c >= 1) {
      const f = Math.floor((c - 1) / 2);
 
      if (this.cpr(this.queue[c], this.queue[f]) > 0) {
        this.swap(c, f);
        c = f;
      } else {
        break;
      }
    }
  }
 
  // 入队
  push(val) {
    this.queue.push(val);
    this.swim();
  }
 
  // 下沉
  sink() {
    let f = 0;
 
    while (true) {
      let c1 = 2 * f + 1;
      let c2 = c1 + 1;
 
      let c;
      let val1 = this.queue[c1];
      let val2 = this.queue[c2];
      if (val1 && val2) {
        c = this.cpr(val1, val2) > 0 ? c1 : c2;
      } else if (val1 && !val2) {
        c = c1;
      } else if (!val1 && val2) {
        c = c2;
      } else {
        break;
      }
 
      if (this.cpr(this.queue[c], this.queue[f]) > 0) {
        this.swap(c, f);
        f = c;
      } else {
        break;
      }
    }
  }
 
  // 出队
  shift() {
    this.swap(0, this.queue.length - 1);
    const res = this.queue.pop();
    this.sink();
    return res;
  }
 
  // 查看顶
  peek() {
    return this.queue[0];
  }
 
  size() {
    return this.queue.length;
  }
}