//查找树中元素  100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
let n;
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 1) {
    n = lines[0] - 0;
  }
 
  if (n && lines.length === n + 2) {
    lines.shift();
    const [tx, ty] = lines.pop().split(" ").map(Number);
    const nodes = lines.map((line) => line.split(" ").map(Number));
 
    console.log(getResult(nodes, tx, ty));
 
    lines.length = 0;
  }
});
 
/**
 *
 * @param {*} nodes 数组，存储树中所有节点，数组元素node也是数组，node = [val, left, right] ，其中val是node节点的内容值，left是node节点的左子节点的索引，right是node节点的右子节点的索引，索引是相对nodes而言的
 * @param {*} tx 目标位置x坐标
 * @param {*} ty 目标位置y坐标
 */
function getResult(nodes, tx, ty) {
  // 2023.03.17，尼玛，谁能想到还有tx,ty小于0的用例，题目描述一点没说
  if (tx < 0 || ty < 0) return "{}";
 
  const matrix = [];
 
  function dfs(node, level) {
    if (!node) return;
 
    // 2023.1.16更新代码逻辑，之前本题只有用例1，因此误以为题目中的树指的是二叉树，因此错误意味一个节点最多只有两个子节点，但是后面补充了更多用例，发现本题的树是多叉树
    // const [val, left, right] = node;
    const val = node[0];
    matrix[level] ? matrix[level].push(val) : (matrix[level] = [val]);
 
    // 2023.1.16更新代码逻辑，之前本题只有用例1，因此误以为题目中的树指的是二叉树，因此错误意味一个节点最多只有两个子节点，但是后面补充了更多用例，发现本题的树是多叉树
    // dfs(nodes[left], level + 1);
    // dfs(nodes[right], level + 1);
    for (let i = 1; i < node.length; i++) {
      dfs(nodes[node[i]], level + 1);
    }
  }
 
  dfs(nodes[0], 0);
 
  if (matrix[tx] && matrix[tx][ty]) {
    return `{${matrix[tx][ty]}}`;
  } else {
    return "{}";
  }
}