// 寻找符合要求的最长子串  满分

/* 寻找符合要求的最长子串
知识点双指针

 时间限制：1s 空间限制：256MB 限定语言：不限

题目描述：
给定一个字符串 s ，找出这样一个子串：
1）该子串中的任意一个字符最多出现2次；
2）该子串不包含指定某个字符；
 请你找出满足该条件的最长子串的长度。
 输入描述：
第一行为要求不包含的指定字符，为单个字符，取值范围[0-9a-zA-Z]
第二行为字符串s，每个字符范围[0-9a-zA-Z]，长度范围[1,10000]
输出描述：
一个整数，满足条件的最长子串的长度；如果不存在满足条件的子串，则返回0
示例1
输入：
D

ABC123

输出：
6

示例2
输入：
D

ABACA123D

输出：
7

解题思路：
使用map对象来统计字符出现的次数。
当出现不包含的字符的时候，清空map
当有字符出现次数到达3次的时候（超过2），对map进行遍历，将出现3次的字符以及它之前的字符全部剔除。
*/

var letter =readline();
var str = String(readline().split(" "))
 
// var strArr = String(str).split('')
var  maxLen = function(letter,str){
    let left = 0;
    let right = 0;
    let len = str.length;
    let res = 0;
    let map = new Map();
    while(right<len){
        let c1 = str[right];
        if(map.has(c1)){
            map.set(c1,map.get(c1)+1)
        }else{
            map.set(c1,1)
        }
        right++;
        while(map.get(letter)==1 || map.get(c1)>2){
            if(map.get(letter) == 1){
                left = right;
                map = new Map();
            }
            if(map.get(c1)>2){
                let c2 = str[left];
                map.set(c2,map.get(c2)-1);
                left++
            }
        }
      res = Math.max(res,right-left)
    }
    return res
}
 
console.log(maxLen(letter,str))