// 货币换算 非正则解法 预计100%
/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
let n;
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 1) {
    n = lines[0] - 0;
  }
 
  if (n && lines.length === n + 1) {
    lines.shift();
    console.log(getResult(lines));
    lines.length = 0;
  }
});
 
function getResult(arr) {
  const exchange = {
    CNY: 100,
    JPY: (100 / 1825) * 100,
    HKD: (100 / 123) * 100,
    EUR: (100 / 14) * 100,
    GBP: (100 / 12) * 100,
    fen: 1,
    cents: 100 / 123,
    sen: 100 / 1825,
    eurocents: 100 / 14,
    pence: 100 / 12,
  };
 
  const str = arr.join("") + "0";
 
  let ans = 0;
  let num = "";
  let unit = "";
  for (let c of str) {
    if (c >= "0" && c <= "9") {
      if (unit != "") {
        ans += Number(num) * exchange[unit];
        num = "";
        unit = "";
      }
      num += c;
    } else if ((c >= "a" && c <= "z") || (c >= "A" && c <= "Z")) {
      unit += c;
    }
  }
 
  return Math.floor(ans);
}