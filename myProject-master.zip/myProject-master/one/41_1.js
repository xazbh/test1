// 静态代码扫描服务  满足

// 解题思路：
// 使用map对象记录各个文件的扫描次数和扫描价格。
// 计算各文件使用缓存和不使用缓存的价格，选择较便宜的方案。

// 本题为考试多行输入输出规范示例，无需提交，不计分。
var readline = require('readline');
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    terminal:false
});
 
var n = -1;// 初始状态为负数，表示还没开始读取
var cur_line = 0;
var line_1 = []
var line_2= []
var notRepeact = []
var tempArr = []
var result = 0
rl.on('line', function(line){ // javascript每行数据的回调接口
   if (n < 0) { // 测试用例第一行读取n
       n = parseInt(line.trim())
   } else {
       if (cur_line === 1) {
            // 矩阵数据读取
            var tokens = line.split(' ');
            line_1 = tokens
        } else if (cur_line === 2) {
            // 矩阵数据读取
            var tokens = line.split(' ');
            line_2= tokens
        }
       
   }
    
    
    // 记录当前读取的行数
    cur_line += 1;
    
   if (cur_line >2) {
       for (var i = 0; i < line_1.length; ++i) {
           if(tempArr.indexOf(parseInt(line_1[i]))  === -1) {
               tempArr.push(parseInt(line_1[i]))
               notRepeact.push({
                   el: parseInt(line_1[i]),
                   N: parseInt(line_2[i]),
                   sum: 0
               })
           }
       }
       for (var i = 0; i < notRepeact.length; ++i) {
           for (var j = 0; j < line_1.length; ++j) {
               if(parseInt(line_1[j]) === notRepeact[i].el) {
                    notRepeact[i].sum += 1
                }
           }
           
       }
//        console.log(notRepeact)
       for (var i = 0; i < notRepeact.length; ++i) {
           result += notRepeact[i].N + n < notRepeact[i].sum * notRepeact[i].N ? notRepeact[i].N + n : notRepeact[i].sum * notRepeact[i].N
       }
      console.log(result)
   }
});