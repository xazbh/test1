// 异常的打卡记录  预计100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
let n;
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 1) {
    n = lines[0] - 0;
  }
 
  if (n && lines.length === n + 1) {
    lines.shift();
    const clockRecords = lines.map((line) => line.split(","));
    console.log(getResult(clockRecords));
    lines.length = 0;
  }
});
 
/**
 * @param {*} clockRecords 打卡记录的字符串数组, [工号, 时间, 打卡距离, 实际设备号, 注册设备号]
 */
function getResult(clockRecords) {
  const employees = {};
 
  const ans = new Set();
 
  for (let i = 0; i < clockRecords.length; i++) {
    const clockRecord = [...clockRecords[i], i]; // 由于异常打卡记录需要按输入顺序输出，因此这里追加一个输入索引到打卡记录中
    const [id, time, dis, act_device, reg_device] = clockRecord;
 
    // 实际设备号与注册设备号不一样,则认为打卡异常
    if (act_device != reg_device) {
      ans.add(i);
    }
 
    // 统计员工的打卡记录(实际设备号与注册设备号不一样的打卡记录也计入)
    employees[id]
      ? employees[id].push(clockRecord)
      : (employees[id] = [clockRecord]);
  }
 
  for (let id in employees) {
    // 某id员工的所有打卡记录
    const records = employees[id];
    const n = records.length;
 
    // 将该员工打卡记录按照打卡时间升序
    records.sort((a, b) => a[1] - b[1]);
 
    for (let i = 0; i < n; i++) {
      const time1 = records[i][1];
      const dis1 = records[i][2];
 
      for (let j = i + 1; j < n; j++) {
        const time2 = records[j][1];
        const dis2 = records[j][2];
 
        // 如果两次打卡时间超过60分钟，则不计入异常，由于已按打卡时间升序，因此后面的都不用检查了
        if (time2 - time1 >= 60) break;
        else {
          // 如果两次打开时间小于60MIN，且打卡距离超过5KM，则这两次打卡记录算作异常
          if (Math.abs(dis2 - dis1) > 5) {
            // 如果打卡记录已经加入异常列表ans，则无需再次加入，否则需要加入
            ans.add(records[i][5]);
            ans.add(records[j][5]);
          }
        }
      }
    }
  }
 
  // 如果没有异常打卡记录，则返回null
  if (!ans.size) return "null";
 
  return [...ans]
    .sort((a, b) => a - b)
    .map((i) => clockRecords[i])
    .join(";");
}