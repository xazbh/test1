// 字符串解密  100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 2) {
    const str1 = lines[0];
    const str2 = lines[1];
 
    console.log(getResult(str1, str2));
 
    lines.length = 0;
  }
});
 
function getResult(str1, str2) {
  const regExp = /[0-9a-f]+/;
 
  const valids = str1.split(regExp);
 
  const count = new Set(str2).size;
 
  const ans = valids.filter(
    (valid) => valid !== "" && new Set(valid).size <= count
  );
 
  if (!ans.length) return "Not Found";
 
  return ans.sort((a, b) => {
    const c1 = new Set(a).size;
    const c2 = new Set(b).size;
    return c1 !== c2 ? c2 - c1 : b > a ? 1 : -1;
  })[0];
}