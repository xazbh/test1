// 识图谱新词挖掘  ?

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 2) {
    const content = lines[0];
    const word = lines[1];
 
    console.log(getResult(content, word));
    lines.length = 0;
  }
});
 
function getResult(content, word) {
  // 如果content长度小于word，则直接返回0
  if (content.length < word.length) {
    return 0;
  }
 
  // count统计word中各字母数量
  const count = {};
  for (let c of word) {
    count[c] ? count[c]++ : (count[c] = 1);
  }
 
  // ans保存题解
  let ans = 0;
 
  // 滑动窗口左指针的移动范围为 0~maxI
  let maxI = content.length - word.length;
  outer: for (let i = 0; i <= maxI; i++) {
    const countb = JSON.parse(JSON.stringify(count));
    const letters = {};
    for (let j = i; j < i + word.length; j++) {
      const c = content[j];
      // 如果滑动窗口j位置字母不属于word，则说明当前滑动窗口内的单词肯定不是word新词，且j之前的所有滑动窗口都毁了，只能从j之后滑动窗口重新开始
      if (count[c] === undefined) {
        i = j;
        continue outer;
      }
 
      // 如果滑动窗口内部字母是word中的，且在规定数量内
      if (countb[c] > 0) {
        // 出现了一个，则规定数量--
        countb[c]--;
        // 记录content中出现的字母的位置
        letters[c] ? letters[c].push(j) : (letters[c] = [j]);
      } else {
        // 如果滑动窗口j位置字母属于word，但是此时由于j位置字母的加入，导致滑动窗口内部对应字母数量超过了word，则说明当前滑动窗口内单词肯定不是word新词
        // 且我们应该让之后的滑动窗口内部该字母数量不能超，因此下一个滑动窗口的起始位置应该是该字母在当前滑动窗口第一次出现位置的下一个位置开始滑动
        i = letters[c][0];
        continue outer;
      }
    }
    ans++;
  }
 
  return ans;
}