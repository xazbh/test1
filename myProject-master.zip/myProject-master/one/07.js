//对称美学  预计100%
/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
let t;
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 1) {
    t = lines[0] - 0;
  }
 
  if (t && lines.length === t + 1) {
    lines.shift();
    const arr = lines.map((line) => line.split(" ").map(BigInt));
    getResult(arr);
 
    lines.length = 0;
  }
});
 
function getResult(arr) {
  for (let [n, k] of arr) {
    console.log(getNK(n, k));
  }
}
 
function getNK(n, k) {
  // 题目没说异常如何处理，因此我默认输入无异常，比如n=1的话，则k只能取0
  if (n === 1n) {
    return "red";
  }
 
  // n=2的话，则k只能取0或1
  if (n === 2n) {
    if (k === 0n) return "blue";
    else return "red";
  }
 
  // 第n个字符串的一半长度half
  let half = 1n << (n - 2n);
 
  if (k >= half) {
    return getNK(n - 1n, k - half);
  } else {
    return getNK(n - 1n, k) === "red" ? "blue" : "red";
  }
}