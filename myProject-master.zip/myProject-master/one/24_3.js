// 找等值元素  100%

 
function main(matrix) {
    let num_map = {}
    let n=matrix.length
    let m = matrix[0].length
    for (let i=0;i<n;i++) {
        for (let j=0;j<m;j++) {
            //将坐标转化为数组
            let pos = [i, j]  
            if(num_map.hasOwnProperty(matrix[i][j])){
                num_map[matrix[i][j]].push(pos)
            }
            else{
                num_map[matrix[i][j]] = []
                num_map[matrix[i][j]].push(pos)
            }
        }
    }
 
 
    let resList = []
    for (let i=0;i<n;i++) {
        let temp_list = []
        for (let j=0;j<m;j++) {
            let pos_list = num_map[matrix[i][j]]
            //无相等值
            if(pos_list.length == 1){  
                temp_list.push(-1);
                continue;
            }
            
 
            let min_distance = Number.MAX_VALUE
            for (let k=0;k<pos_list.length;k++) {
                pos = pos_list[k]
                distance = Math.abs(pos[0]-i) + Math.abs(pos[1]-j)
                //距离为0则跳过
                if(distance == 0){ 
                    continue
                }
                min_distance = Math.min(min_distance, distance)
            }
        
 
            temp_list.push(min_distance)
        }
 
        resList.push(temp_list)
    }
    console.log(JSON.stringify(resList).replace(/,/g, ", ");)
}
 
 
main([[0, 3, 5 ,4 ,2],[2, 5 ,7, 8, 3],[2 ,5, 4, 2, 4]])