//获得完美走位  满分
//let str = readline();
let str = "AAAWDWASSDDD";
 
const len = str.length;
//完美走位中各走位的平均个数
const perfect = len / 4;
let offset = new Map();
for(let i=0; i<len; i++){
    let char = str.charAt(i);
    if(offset.has(char)){
        offset.set( char, offset.get(char) + 1);
    }else{
        offset.set( char, 1 - perfect);
    }
}
 
let min = len;
for (let i = 0; i < len; i++) {
    let copy = new Map(offset);
    let len = 0;
    if (copy.get(str.charAt(i)) > 0) {
        for (let j = i; j < str.length; j++) {
            let c = str.charAt(j);
            copy.set(c, copy.get(c) - 1);
            len++;
            if (allClear(copy)) {
                break;
            }
        }
    }
    if (allClear(copy)){
        min = Math.min(min, len);
    }
}
 
console.log(min);
 
function allClear(copy) {
    let values = copy.values();
    for (let value of values) {
        if (value > 0) {
            return false;
        }
    }
    return true;
}