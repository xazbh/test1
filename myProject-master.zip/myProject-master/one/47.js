// 字符串重新排列、字符串重新排序  100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
rl.on("line", (line) => {
  const arr = line.split(" ");
  console.log(getResult(arr));
});
 
function getResult(arr) {
  arr = arr.map((str) => [...str].sort().join(""));
 
  const count = arr.reduce((p, c) => {
    p[c] ? p[c]++ : (p[c] = 1);
    return p;
  }, {});
 
  arr.sort((a, b) =>
    count[a] !== count[b]
      ? count[b] - count[a]
      : a.length !== b.length
      ? a.length - b.length
      : a > b
      ? 1
      : -1
  );
 
  return arr.join(" ");
}