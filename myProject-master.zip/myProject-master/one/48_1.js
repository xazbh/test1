// MVP争夺战  满分

/** 
解题思路：
此题应该是正确率最低的题目了，只有0.71%；

首先对得分数组进行排序，确定平均得分的最小值和最大值。

最小值：得分数组的最大值（因为每一分钟的得分都只能由某一个人包揽）

最大值：得分总数/2（最低两个人平分）

从最小值遍历到最大值，需要注意的是，只有总得分整除平均分时才有必要去判断。判断的时候需要从最大值开始遍历（也就是得分数组尾部）

如示例1：

9

5 2 1 5 2 1 5 2 1

对数组进行排序  1 1 1 2 2 2 5 5 5  总分24

最小平均分：5，最大平均分：24/2=12

当n=5：（从数组尾部开始）

i=8，ints[8]=5，5-5=0，则满足平均分，使用过的得分置零ints[8]=0

i=7，ints[7]=5，5-5=0，则满足平均分，使用过的得分置零ints[7]=0

i=6，ints[6]=5，5-5=0，则满足平均分，使用过的得分置零ints[6]=0

i=5，ints[5]=2，5-2=3；

        i=4，ints[4]=2，3-2=1；

        …

        i=2，ints[2]=1，1-1=0，满足平均分，使用过的得分置零ints[5]= ints[4]= ints[2]=0；

i=4，ints[4]=0，跳过。

i=3，ints[3]=2，5-2=3；

        i=2，ints[2]=0，跳过；

        i=1，ints[1]=1，3-1=2；i=0，ints[0]=1，2-1=1，不满足平均分。

最终数组剩下的总分4！=0，说明不能对平均分=5进行平分。

当n=6：（从数组尾部开始）

i=8，ints[8]=5，n=6-5=1；

        i=7，ints[7]=5，1-5=-4<0，还原到n=1；

        i=6，ints[6]=5，1-5=-4<0，还原到n=1；

        i=5，ints[5]=2，1-2=-1<0，还原到n=1；

        …

        i=2，ints[2]=1，1-1=0，,满足平均分，使用过的得分置零ints[8]= ints[2]=0;

i=7，ints[7]=5，n=6-5=1；

        i=6，ints[6]=5，1-5=-4<0，还原到n=1；

        i=5，ints[5]=2，1-2=-1<0，还原到n=1；

        …

        i=2，ints[2]=0,跳过；

        i=1，ints[1]=1，1-1=0，满足平均分，使用过的得分置零ints[7]= ints[1]=0;

i=6，ints[6]=5，n=6-5=1；

        i=5，ints[5]=2，1-2=-1<0，还原到n=1；

        i=4，ints[4]=2，1-2=-1<0，还原到n=1；

        …

        i=2，ints[2]=0,跳过；

        i=1，ints[1]=0，跳过；

        i=0，ints[0]=1，1-1=0，满足平均分，使用过的得分置零ints[6]= ints[0]=0;

i=5，ints[5]=2，n=6-2=4；

        i=4，ints[4]=2，4-2=2；

        i=3，ints[3]=2，2-2=0，满足平均分，使用过的得分置零ints[5]= ints[4]= ints[3]=0;

最终数组剩下的总分0==0，说明能对平均分=6进行平分。

以此类推。。。

最终最少的MVP得分为6

以下测试用例是真实机试中的：

20 1 2 3 4 5 6 7 8 9 21 23 24 25 26 28 27 26 29
3 1 4 10
4 1 2 3 4
1 1
9 5 2 1 5 2 1 5 2 1
40 6 6 6 6 6 6 6 6 6 6 9 9 9 9 9 9 9 9 9 9 40 40 40 40 40 40 40 40 40 40 1 2 3 9 8 7 4 5 6 10
11 8 50 49 1 1 13 15 17 49 50 50 
*/

// let t = Number(readline());
// let ints = readline().split(" ").map(Number);
let t = Number("9");
let ints = "5 2 1 5 2 1 5 2 1".split(" ").map(Number);
 
let total = 0;
var maxn = Math.max(...ints);
var minn = Math.min(...ints);
//各得分的个数数组
var cnt = new Array(51).fill(0);
//已经完成平分得分
var isOver = false;
//原代码95分，唯一错误用例20 1 2 3 4 5 6 7 8 9 21 23 24 25 26 28 27 26 29
//所有这边的边界不能用t，只能用得分p的长度
for (let i = 0; i < ints.length; i++) {
    cnt[ints[i]] ++;
    total += ints[i];
}
 
let res = 0;
for (let i = maxn; i <= total / 2; i++) {
    if (total % i == 0) {
        dfs(total /i, 0, i, maxn);
        if(isOver){
            res = i;
            break;
        }
    }
}
 
console.log(res == 0 ? total : res);
 
function dfs( res, sum, target, p) {
    if (res == 0) {
        isOver = true;
    }
 
    if (sum == target) {
        dfs(res -1, 0, target, maxn);
        return;
    }
 
    for (let i = p; i >= minn; --i) {
        if (cnt[i] > 0 && (i + sum) <= target) {
            cnt[i] --;
            dfs(res, sum + i, target, i);
            cnt[i] ++;
            if (sum == 0 || (sum + i) == target) {
                break;
            }
        }
    }
}