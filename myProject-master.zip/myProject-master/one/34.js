// 最大报酬  100%

// 方法1
/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
let T, n;
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 1) {
    [T, n] = lines[0].split(" ").map(Number);
  }
 
  if (n && lines.length === n + 1) {
    lines.shift();
    const tws = lines.map((line) => line.split(" ").map(Number));
    console.log(getResult(T, tws));
    lines.length = 0;
  }
});
 
/**
 *
 * @param {*} T 工作时长
 * @param {*} tws 数组，元素是tw，也是数组，含义为[该工作消耗的时长, 该项工作的报酬]
 */
function getResult(T, tws) {
  const maxI = tws.length + 1;
  const maxJ = T + 1;
  const dp = new Array(maxI).fill(0).map(() => new Array(maxJ).fill(0)); // 默认将dp数组元素全部初始化为0
 
  for (let i = 0; i < maxI; i++) {
    for (let j = 0; j < maxJ; j++) {
      if (i === 0 || j === 0) continue; // 第0行或第0列最大报酬保持0
      const [t, w] = tws[i - 1]; // 要选择的工作的[权重，价值]
      if (t > j) {
        // 如果要选择的工作的权重 > 当前背包权重，则无法放入背包，最大价值继承自上一行该列值
        dp[i][j] = dp[i - 1][j];
      } else {
        // 如果要选择的工作的权重 <= 当前背包权重
        // 则我们有两种选择
        // 1、不进行该工作，则最大价值继承自上一行该列值
        // 2、进行该工作，则纳入该工作的价值w，加上+ 剩余权重，在不进行该工作的范围内，可得的最大价值dp[i - 1][j - t]
        // 比较两种选择下的最大价值，取最大的
        dp[i][j] = Math.max(dp[i - 1][j], w + dp[i - 1][j - t]);
      }
    }
  }
 
  return dp.at(-1).at(-1); // 取二维数组最右下角元素作为题解
}