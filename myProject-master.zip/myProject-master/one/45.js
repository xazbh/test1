// 荒地、光伏场地建设规划  预计100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
let len, wid, sid, min;
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 1) {
    [len, wid, sid, min] = lines[0].split(" ").map(Number);
  }
 
  if (len && lines.length === len + 1) {
    const matrix = lines.slice(1).map((line) => line.split(" ").map(Number));
    console.log(getResult(len, wid, sid, min, matrix));
    lines.length = 0;
  }
});
 
/**
 * @param {*} r 调研区域的行数
 * @param {*} c 调研区域的列数
 * @param {*} s 正方形电站的边长
 * @param {*} min 正方形电站的最低发电量
 * @param {*} matrix 调研区域每单位面积的发电量矩阵
 */
function getResult(r, c, s, min, matrix) {
  const preSum = new Array(r + 1).fill(0).map(() => new Array(c + 1).fill(0));
 
  for (let i = 1; i <= r; i++) {
    for (let j = 1; j <= c; j++) {
      preSum[i][j] =
        preSum[i - 1][j] +
        preSum[i][j - 1] -
        preSum[i - 1][j - 1] +
        matrix[i - 1][j - 1];
    }
  }
 
  let ans = 0;
 
  for (let i = s; i <= r; i++) {
    for (let j = s; j <= c; j++) {
      const square =
        preSum[i][j] -
        (preSum[i - s][j] + preSum[i][j - s]) +
        preSum[i - s][j - s];
 
      if (square >= min) ans++;
    }
  }
 
  return ans;
}