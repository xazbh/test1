// 静态扫描  100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
let m, f, s;
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 3) {
    m = lines[0] - 0;
    f = lines[1].split(" ").map(Number);
    s = lines[2].split(" ").map(Number);
 
    console.log(getResult(m, f, s));
 
    lines.length = 0;
  }
});
 
function getResult(m, f, s) {
  // count用于保存每个文件出现的次数
  const count = {};
  // size用于保存文件的大小，即扫描成本
  const size = {};
  for (let i = 0; i < f.length; i++) {
    // k是文件标识
    const k = f[i];
    count[k] ? count[k]++ : (count[k] = 1);
    if (!size[k]) {
      size[k] = s[i];
    }
  }
 
  let ans = 0;
  for (let k in count) {
    // 选择每次都重新扫描的成本  和  扫描一次+缓存的成本  中最小的
    ans += Math.min(count[k] * size[k], size[k] + m);
  }
 
  return ans;
}