//数组的中心位置  满分
while(line = readline()) {
    var lineArr = line.split(' ');
    let len = lineArr.length;
    let res = -1;
    for(let i = 0; i < len; i++) {
        let lm = 1;
        let rm = 1;
        for(let j = 0; j <= i; j++) {
            lm = lineArr[j]*lm;
        }
        for(let k = i; k < len; k++) {
            rm = lineArr[k]*rm;
        }
        if (rm === lm) {
            res = i
            break;
        }
    }
    console.log(res);
}