// 新学校选址  100%

// let n = Number(readline());
// let array = readline().split(" ").map(Number);
let n = Number("5");
let array = "0 20 40 10 30".split(" ").map(Number);
 
let minSite = getMinSite(array);
console.log(minSite);
 
function getMinSite(array) {
  array.sort();
  if (array.length % 2 == 0) {
    return array[Math.floor(array.length / 2) - 1];
  } else {
    return array[Math.floor(array.length / 2)];
  }
}