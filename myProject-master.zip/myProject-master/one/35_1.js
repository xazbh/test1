// 预定酒店  满分

// 解题思路：
// 1、使用hotel类来记录酒店价格和心理差价
// 2、根据心理差价，从集合中获取合适的酒店，并按照差价进行降序排序
// 3、根据k值获取集合中的酒店价格，然后对价格进行升序输出

//let input1 = readline().split(" ").map(Number);
let input1 = "6 3 1000".split(" ").map(Number);
let n = input1[0];
let k = input1[1];
let x = input1[2];
 
//let integers = readline().split(" ").map(Number);
let integers = "30 30 200 500 70 300".split(" ").map(Number);
 
let res = [];
for (let i = 0; i < integers.length; i++) {
    let integer = integers[i];
    let ints = [];
    let abs = Math.abs(integer - x);
    ints[0] = integer;
    ints[1] = abs;
    res.push(ints);
}
 
res.sort((o1, o2) => {
    if (o1[1] == o2[1]) {
        return o1[0] - o2[0];
    } else {
        return o1[1] - o2[1];
    }
});
 
let integers1 = [];
for (let i = 0; i < k; i++) {
    let i1 = res[i][0];
    integers1.push(i1);
}
 
integers1.sort();
let sb = "";
for (let i = 0; i < integers1.length; i++) {
    sb += integers1[i] + " ";
}
 
console.log(sb.substring(0, sb.length - 1));