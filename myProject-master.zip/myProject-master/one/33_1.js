// 相同数字的积木游戏1  满分

// 解题思路：
// 将积木转化为数组。
// 遍历数组
// 第一个数从头开始遍历，第二个数从尾开始遍历。当两数相等时，计算其索引差值，即为距离。求得其中最大值。

const count = readline();
let arr =[], max = -1
while(line=readline()){
    arr.push(line)
}
let map = new Map();
for(let i=0;i<arr.length;i++){
    if(map.has(arr[i])){
        max = Math.max(max,i-map.get(arr[i]))
    }else{
        map.set(arr[i],i)
    }
}
console.log(max)