//满分 猜字谜
const rl = require("readline").createInterface({ input: process.stdin });
var iter = rl[Symbol.asyncIterator]();
const readline = async () => (await iter.next()).value;
 
void (async function () {
    // Write your code here
    let qu = [];
    let an = [];
    while ((line = await readline())) {
        let tokens = line.split(" ");
        if (qu.length === 0) {
            qu = tokens[0].split(',');
        } else {
            an = tokens[0].split(",");
        }
    }
    const an2 = JSON.parse(JSON.stringify(an));
    const result = []
    for (let i = 0; i < an.length; i++) {
        an[i] = [...new Set(an[i].split("").sort())];
        an[i] = an[i].join("");
    }
    for (let i = 0; i < qu.length; i++) {
        qu[i] = [...new Set(qu[i].split("").sort())];
        qu[i] = qu[i].join("");
        const index = an.findIndex(el=>el === qu[i])
        if(index !== -1) {
            result.push(an2[index])
        }else {
            result.push('not found')
        }
    }
    //console.log(qu,an)
    console.log(result.join(','))
})();