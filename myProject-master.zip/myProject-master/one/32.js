// 租车骑绿岛  100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 2) {
    const [m, n] = lines[0].split(" ").map(Number);
    const arr = lines[1].split(" ").map(Number);
 
    console.log(getResult(arr, m, n));
 
    lines.length = 0;
  }
});
 
function getResult(arr, m, n) {
  arr.sort((a, b) => a - b);
 
  let count = 0;
 
  // while (arr.at(-1) >= m) {
  //   count++;
  //   arr.pop();
  // }
 
  let i = 0;
  let j = arr.length - 1;
 
  while (i < j) {
    if (arr[i] + arr[j] <= m) i++;
    j--;
    count++;
  }
 
  if (i === j) count++;
 
  return count;
}