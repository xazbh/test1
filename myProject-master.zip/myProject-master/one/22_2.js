// 投篮大赛  100%  No.56

 
function main(input_str) {
    let operations = input_str.split(" ")
    let scores = [];
 
    for (let op of operations) {
        // 判断是否为整数
        if (/^\-?\d+$/.test(op)) {
            scores.push(op - 0);
        } else {
            if (op == "+") {
                if (!scores[scores.length-1] || !scores[scores.length-2]) {
                    console.log(-1)
                    return
                }
                scores.push(scores[scores.length-1] + scores[scores.length-2]);
            } else if (op == "D") {
                if (!scores[scores.length-1]) {
                    console.log(-1)
                    return
                }
                scores.push(scores[scores.length-1] * 2);
            } else if (op == "C") {
                if (!scores[scores.length-1]) {
                    console.log(-1)
                    return
                }
                scores.pop();
            }
        }
            
    }
    if (scores.length==0){
        console.log(0)
    } else {
        console.log(eval(scores.join("+")))
    }
    
}
 
 
main("5 C")
 