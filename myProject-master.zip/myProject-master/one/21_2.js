// 字符串解密  100%  No.68

//JSRUN引擎2.0,支持多达30种语言在线运行,全仿真在线交互输入输出。
function main(string1, string2) {
    const valids = string1.split(/[0-9a-f]+/);
 
    const count = new Set(string2).size;
 
    const result = valids.filter(
    (valid) => valid !== "" && new Set(valid).size <= count
    );
 
    if (!result.length) {
        console.log("Not Found")
        return
    }
 
    console.log(result.sort((a, b) => {
        const c1 = new Set(a).size;
        const c2 = new Set(b).size;
        return c1 !== c2 ? c2 - c1 : b > a ? 1 : -1;
    })[0])
}
 
 
main("123admyffc79pt","ssyy")