// 字符串重新排序  满分

/** 
解题思路：
1、使用map来记录单词的使用次数（根据题意需要先对单词进行字母排序，也就是说只要字母都相同的就是同一个单词，不管其顺序）

2、将map转化为list进行sort排序，排序规则：

使用次数进行降序（map中value大的排在前面）
使用次数相同时，根据key的长度升序（key的长度短的排在前）
长度相同时，根据字典序进行升序
3、最后按序输出list中的字符
*/

const readline = require('readline');
 
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});
rl.on('line', function (line) {
    let symArray = line.split(' ');
    let symObject = {}
    symArray = symArray.map(res=>{
        return res.split('').sort().join('')
    })
    symArray.forEach(res=>{
        if(symObject[res]){
            symObject[res]++;
        }else{
            symObject[res]=1;
        }
    })
// symArray = Array.from(new Set([...symArray]))
    symArray.sort((a,b)=>{
        if(symObject[b] != symObject[a]){
            return symObject[b] - symObject[a]
        } else if(b.length != a.length){
            return a.length - b.length
        } else {
            for(let i=0;i<b.length;i++){
                if(a[i]!==b[i]){
                    return a.charCodeAt(i)-b.charCodeAt(i)
                }
            }
        }
    })
    console.log(symArray.join(' '))
});