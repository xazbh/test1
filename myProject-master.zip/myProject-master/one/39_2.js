// 最接近最大输出功率的设备 /查找充电设备组合  100%  No.84

function main(n,p,p_max) {
    //dp[i][j] 表示从下标为[0-i]的物品里任意取，放进容量为j的背包，价值总和最大是多少。
    let dp = new Array(n+1)
    for (let i=0;i<n+1;i++) {
        dp[i] = new Array(p_max+1).fill(0)
    }
 
    // 初始化, i为0，存放编号0的物品的时候，各个容量的背包所能存放的最大价值。
    let j = p_max
    while(j >= p[0]){
        dp[0][j] = dp[0][j - p[0]] + p[0]
        j -= 1
    }
 
    for (let i=1;i<n;i++){  // 遍历物品
        for (let j=0;j<p_max+1;j++) { // 遍历背包容量
            // 背包容量为j，如果物品i的体积，此时dp[i][j]就是dp[i - 1][j]
            if (j < p[i])
                dp[i][j] = dp[i - 1][j]
            else
                dp[i][j] = Math.max(dp[i - 1][j], dp[i - 1][j - p[i]] + p[i])
        }
    }
 
    console.log(dp[n-1][p_max])
    
}
 
main(4,[50, 20, 20, 60],90)