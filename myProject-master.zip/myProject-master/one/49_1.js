// 贪心的商人  ?

/** 
解题思路：
通过双层for循环来求得最大利润；

第一层：商品的循环，索引为number

第二层：商品每天的价格，索引为day

题目说可以进行多次买卖，我们就今日买，隔天卖（大于进价时）。抓住每次利润，实现利润最大化。
*/

// let number = Number(readline());
// let days = Number(readline());
let number = Number("3");
let days = Number("3");
 
// let item = readline().split(" ").map(Number);
let item = "4 5 6".split(" ").map(Number);
 
let item_price = [];
let test = [
            "1 2 3",
            "4 3 2",
            "1 5 3"
        ];
for(let i=0; i<number; i++){
    //item_price[i] = readline().split(" ").map(Number);
    item_price[i] = test[i].split(" ").map(Number);
}
 
let res = 0;
for(let i=0; i<number; i++){
    for(let j=0; j<days-1; j++){
        let purchase = item_price[i][j];    //进价
        let selling = item_price[i][j+1];     //卖价
        if(selling > purchase){     //当卖价大于进价才有利润
            res += (selling - purchase) * item[i];   //还需要乘以其数量
        }
    }
}
 
console.log(res);