// 端口合并 ？
/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
let m;
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 1) {
    m = lines[0] - 0;
 
    // M,N不在限定范围内，统一输出一组空数组[[]]
    if (m > 10 || m < 1) {
      console.log("[[]]");
      lines.length = 0;
      return;
    }
  }
 
  if (m && lines.length === m + 1) {
    lines.shift();
    const ports = lines.map((line) => line.split(",").map(Number));
 
    for (let port of ports) {
      const n = port.length;
      // M,N不在限定范围内，统一输出一组空数组[[]]
      if (n < 1 || n > 100) {
        console.log("[[]]");
        lines.length = 0;
        return;
      }
    }
 
    console.log(getResult(ports, m));
    lines.length = 0;
  }
});
 
function getResult(ports, m) {
  ports = ports.map((port) => new Set(port));
 
  outer: while (true) {
    for (let i = m - 1; i >= 0; i--) {
      if (ports[i].size == 0) continue;
 
      for (let j = i - 1; j >= 0; j--) {
        if (ports[j].size == 0) continue;
 
        if (hasTwoSamePort(ports[i], ports[j])) {
          ports[j] = new Set([...ports[i], ...ports[j]]);
          ports[i].clear();
          continue outer;
        }
      }
    }
    break;
  }
 
  return JSON.stringify(
    ports
      .filter((port) => port.size > 0)
      .map((port) => [...port].sort((a, b) => a - b))
  );
}
 
function hasTwoSamePort(p1, p2) {
  let count = 0;
  for (let p of p1) {
    if (p2.has(p)) {
      if (++count >= 2) return true;
    }
  }
 
  return false;
}