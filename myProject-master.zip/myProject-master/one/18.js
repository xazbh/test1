// 获取最大软件版本号  100%

// 非正则
/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 2) {
    console.log(getResult(lines[0], lines[1]));
    lines.length = 0;
  }
});
 
function getResult(s1, s2) {
  const [major1, minor1, patch1, mile1] = getVersion(s1);
  const [major2, minor2, patch2, mile2] = getVersion(s2);
 
  if (major1 > major2) return s1;
  else if (major1 < major2) return s2;
 
  if (minor1 > minor2) return s1;
  else if (minor1 < minor2) return s2;
 
  /**
   * 注意下面JS判断与空串是否相同时，必须要使用===，不能使用==，因为 0 == "" 为true
   */
 
  if (patch1 !== "" || patch2 !== "") {
    if (patch2 === "") {
      return s1;
    } else if (patch1 === "") {
      return s2;
    }
 
    // 走到此步，说明s1,s2的增量版本都不是空串，此当成数字进行比较
    if (patch1 > patch2) {
      return s1;
    } else if (patch1 < patch2) {
      return s2;
    }
  }
 
  // s1,s2的里程碑的空串判断，同增量版本
  if (mile2 === "") {
    return s1;
  } else if (mile1 === "") {
    return s2;
  }
 
  // 如果s1，s2的里程碑版本都不是空串，则按照字典序比较
  return s1 >= s2 ? s1 : s2;
}
 
function getVersion(s) {
  let major = "";
  let minor = "";
  let patch = "";
  let mile = "";
 
  // 找到第一个“-”,先把里程碑解析出来，因为里程碑中可能含有"-"和".",因此必须先处理掉
  const i = s.indexOf("-");
 
  let major_minor_pathc = "";
  if (i != -1) {
    mile = s.slice(i + 1);
    major_minor_pathc = s.slice(0, i);
  } else {
    major_minor_pathc = s;
  }
 
  // 之后再处理非里程碑部分
  const tmp = major_minor_pathc.split(".");
  major = Number(tmp[0]);
  minor = Number(tmp[1]);
 
  if (tmp.length > 2) {
    patch = Number(tmp[2]);
  }
 
  return [major, minor, patch, mile];
}