// 学校的位置  满分

// 解题思路：
// 1、求出数组中的最大值和最小值作为学习可选位置的区间。
// 2、遍历步骤1中的位置到各学生家位置之和，求出其最小值的位置

// let n = Number(readline());
// let array = readline().split(" ").map(Number);
let n = Number("5");
let array = "0 20 40 10 30".split(" ").map(Number);
 
let minSite = getMinSite(array);
console.log(minSite);
 
function getMinSite(array){
    array.sort();
    if (array.length % 2 == 0){
        return array[Math.floor(array.length/2) - 1];
    }else {
        return array[Math.floor(array.length/2)];
    }
}