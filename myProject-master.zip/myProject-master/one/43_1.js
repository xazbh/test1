// AI处理器组合  满分

/** 
解题思路：
这题主要还是逻辑题。
主要难点是：
需要考虑可用处理器数量的优先级；
需要求出申请处理器的所有可能性。
*/

//let input1 = readline();
let input1 = "[0, 1, 2, 3, 4, 5, 6]";
let arr = input1.substring(1, input1.length - 1).split(",").map(Number);
//链路1可用的处理器个数
let v1 = 0;
//链路2可用的处理器个数
let v2 = 0;
//处理器数组
let vis = [];
let ans = [];
for (let i = 0; i < arr.length; i++) {
    let num = arr[i];
    vis[num] = 1;
    if (num < 4) {
        v1++;
    } else {
        v2++;
    }
}
 
//let val = Number(readline());
let val = Number("2");
if (val == 1) {
    //申请1个处理器
    let state = 0;
    //亲和度判断
    if (v1 == 1 || v2 == 1) state = 1;
    else if (v1 == 3 || v2 == 3) state = 3;
    else if (v1 == 2 || v2 == 2) state = 2;
    else if (v1 == 4 || v2 == 4) state = 4;
    if (v1 == state) {
        for (let i = 0; i < 4; i++) {
            if (vis[i] == 1) {
                let tmp = [];
                tmp.push(i);
                ans.push(tmp);
            }
        }
    }
    if (v2 == state) {
        for (let i = 4; i < 8; i++) {
            if (vis[i] == 1) {
                let tmp = [];
                tmp.push(i);
                ans.push(tmp);
            }
        }
    }
} else if (val == 2) {
    //申请2个处理器
    let state = 0;
    if (v1 == 2 || v2 == 2) state = 2;
    else if (v1 == 4 || v2 == 4) state = 4;
    else if (v1 == 3 || v2 == 3) state = 3;
    if (v1 == state) {
        for (let i = 0; i < 4; i++) {
            for (let j = i + 1; j < 4; j++) {
                if (i != j && vis[i] == 1 && vis[j] == 1) {
                    let tmp = [];
                    tmp.push(i);
                    tmp.push(j);
                    ans.push(tmp);
                }
            }
        }
    }
    if (v2 == state) {
        for (let i = 4; i < 8; i++) {
            for (let j = i + 1; j < 8; j++) {
                if (i != j && vis[i] == 1 && vis[j] == 1) {
                    let tmp = [];
                    tmp.push(i);
                    tmp.push(j);
                    ans.push(tmp);
                }
            }
        }
    }
} else if (val == 4) {
    //申请4个处理器
    if (v1 == 4) {
        let tmp = [];
        for (let i = 0; i < 4; i++) {
            tmp.push(i);
        }
        ans.push(tmp);
    }
    if (v2 == 4) {
        let tmp = [];
        for (let i = 4; i < 8; i++) {
            tmp.push(i);
        }
        ans.push(tmp);
    }
} else if (val == 8) {
    //申请8个处理器
    if (v1 == 4 && v2 == 4) {
        let tmp = [];
        for (let i = 0; i < 8; i++) {
            tmp.push(i);
        }
        ans.push(tmp);
    }
}
 
console.log(ans);