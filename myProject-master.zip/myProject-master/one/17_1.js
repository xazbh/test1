//开心消消乐  满分
// 解题思路
// 主要使用回溯进行深度搜索；
// 遍历二维数组，碰到1的时候判断其四周八个方向是否为1，如果是1，将其改为0，且对其坐标周围继续探索。
let N = 0;
let M = 0;
let arr = [];
let count = 0;
while ((line = readline())) {
    let cur = line.split(" ").map((v) => parseInt(v));
    if (N == 0) {
        N = cur[0];
        M = cur[1];
    } else {
        arr.push(cur);
    }
}
// 中心两侧查找
for (let i = 0; i < N; i++) {
    for (let j = 0; j < M; j++) {
        if (arr[i][j] == 1) {
            changeX(i,j);
            count+=1;
        }
    }
}
console.log(count);
// 交换
function changeX(i,j) {
    if (i<0 || j <0 || i > N - 1 || j > M-1 || arr[i][j] !== 1) {
        return;
    }
    if(arr[i][j] == 1) {
        arr[i][j] = 0;
    }
    changeX(i-1,j-1);
    changeX(i-1,j);
    changeX(i-1,j+1);
    changeX(i,j-1);
    changeX(i,j+1);
    changeX(i+1,j-1);
    changeX(i+1,j);
    changeX(i+1,j+1);
}