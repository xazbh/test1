// 预订酒店  100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 2) {
    const [n, k, x] = lines[0].split(" ").map(Number);
    const prices = lines[1].split(" ").map(Number);
 
    console.log(getResult(n, k, x, prices));
 
    lines.length = 0;
  }
});
 
function getResult(n, k, x, prices) {
  const tmp = [];
 
  for (let p of prices) {
    tmp.push([p, Math.abs(p - x)]);
  }
 
  tmp.sort((a, b) => (a[1] != b[1] ? a[1] - b[1] : a[0] - b[0]));
 
  return tmp
    .slice(0, k)
    .map((arr) => arr[0])
    .sort((a, b) => a - b)
    .join(" ");
}