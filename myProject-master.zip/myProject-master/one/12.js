// 简单的自动曝光、平均像素值   100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
rl.on("line", (line) => {
  const arr = line.split(" ").map(Number);
  console.log(getResult(arr));
});
 
function getResult(arr) {
  const len = arr.length;
  let minDiff = Infinity;
  let ans;
 
  for (let k = -127; k <= 128; k++) {
    let sum = 0;
    for (let j = 0; j < len; j++) {
      let newVal = arr[j] + k;
      // 新图的像素值会自动截取到[0,255]范围。当新像素值<0，其值会更改为0；当新像素值>255，其值会更改为255；
      newVal = newVal < 0 ? 0 : newVal > 255 ? 255 : newVal;
      sum += newVal;
    }
 
    const diff = Math.abs(sum / len - 128);
 
    if (diff < minDiff) {
      minDiff = diff;
      ans = k;
    } else if (diff === minDiff) {
      // 如有多个整数k都满足，输出小的那个k
      ans = Math.min(ans, k);
    }
  }
 
  return ans;
}