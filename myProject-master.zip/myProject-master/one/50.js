// 总最快检测效率 核酸  ？

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 2) {
    const [x, y] = lines[0].split(" ").map(Number);
    const arrX = lines[1].split(" ").map(Number);
 
    console.log(getResult(arrX, x, y));
    lines.length = 0;
  }
});
 
/**
 *
 * @param {*} x 采样员人数
 * @param {*} arr 每个采样员的正常效率
 * @param {*} y 志愿者人数
 */
function getResult(arr, x, y) {
  // 按照正常效率降序
  arr.sort((a, b) => b - a);
 
  let max = 0;
 
  let i;
  let j;
  let count = 0;
 
  // 如果志愿者少于采样员，则优先将志愿者分配给正常效率高的采样员
  if (y < x) {
    for (let i = 0; i < x; i++) {
      // 0~y-1范围内高效率的采样员优先获得一个志愿者，因此保持正常效率，而y~x-1范围内的低效率采样员则没有志愿者，效率下降20%
      max += i < y ? arr[i] : arr[i] * 0.8;
    }
 
    i = 0;
    j = y - 1;
  }
  // 如果志愿者 不少于 采样员，那么默认情况下每个采样员都分配一个志愿者
  else {
    // 如果志愿者人数超过采样员四倍，则多出来的志愿者就没有作用了
    if (y >= 4 * x) {
      y = 4 * x;
    }
 
    // 每个采样员都默认发挥正常效率
    max = arr.reduce((p, c) => p + c);
 
    // surplus记录每个采样员分配一个志愿者后，还多出来的志愿者
    let surplus = y - x;
 
    i = 0;
    j = x - 1;
 
    // 优先将多出来的志愿者分配给高效率的采样员
    while (surplus > 0) {
      max += arr[i] * 0.1;
      surplus--;
      if (++count === 3) {
        count = 0;
        i++;
      }
    }
  }
 
  // 多出来的志愿者分配完后，则继续考虑剥夺低效率采样员的志愿者给高效率的采样员
  while (i < j) {
    // 接下来，我们需要比较最高效率的采样员上升10%的效率  是否大于  最低效率的采样员下降20%的效率
    if (arr[i] * 0.1 > arr[j] * 0.2) {
      // 如果大于，则将效率低的采样员的志愿者分配给效率高的采样员
      max += arr[i] * 0.1 - arr[j] * 0.2;
      // 由于一个采样员最多只能提升30%，即除了一个基础志愿者外，最多再配3个志愿者，多配了也没用
      if (++count === 3) {
        count = 0;
        i++;
      }
      j--;
    } else {
      break;
    }
  }
 
  return max;
}