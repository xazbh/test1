// 最多颜色的车辆  100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 2) {
    const arr = lines[0].split(" ");
    const n = parseInt(lines[1]);
 
    console.log(getResult(arr, n));
 
    lines.length = 0;
  }
});
 
function getResult(arr, n) {
  // count用于统计滑动窗口内各种颜色的数目
  const count = {
    0: 0,
    1: 0,
    2: 0,
  };
 
  // 初始滑动窗口的左右边界，注意这里的右边界r是不包含了，为了方便后面进行slice
  let l = 0;
  let r = l + n;
 
  // 统计初始滑动窗口中各种颜色的数量
  arr.slice(l, r).forEach((c) => {
    count[c]++;
  });
 
  // 将初始滑动窗口内部最多颜色数量给max
  let max = Math.max.apply(null, Object.values(count));
 
  // 如果滑动窗口右边界未达到数组尾巴，就继续右移
  // 注意，初始滑窗的右边界r是不包含的，因此r可以直接当成下一个滑窗的右边界使用
  while (r < arr.length) {
    // 当滑动窗口右移后，新的滑动窗口相比移动前来看，新增了arr[r]，失去了arr[l]，注意此时左边界l还是指向上一个滑窗的左边界，而不是新滑窗的左边界，因此可以直接通过arr[l]取得失去的
    const add = arr[r++];
    const remove = arr[l++];
 
    count[add]++;
    count[remove]--;
 
    // 只有新增数量的颜色可能突破最大值
    max = Math.max(max, count[add]);
  }
 
  return max;
}