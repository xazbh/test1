// 箱子之字形摆放  100%

//JSRUN引擎2.0,支持多达30种语言在线运行,全仿真在线交互输入输出。
 
//并查集模板
class UF {
    constructor(n) {
        this.count = n
        this.item = new Array(n)
        for(let i=0;i<n;i++) {
            this.item[i]=i
        }
    }
    
    find(x) {
        if (x !== this.item[x]) {
            return (this.item[x] = this.find(this.item[x]))
        }
        return x
    }
    
    union_connect(x, y) {
        let x_item = this.find(x)
        let y_item = this.find(y)
    
        if (x_item !== y_item) {
            this.item[y_item] = x_item
            this.count--
        }
    }
}
 
function main(input_str, n) {
 
    let box_map = new Array(n)
    for (let i=0;i<n;i++){
        box_map[i] = new Array()
    }
    
    let flag = true
    for (let i = 0; i < input_str.length; i++) {
        k = i % n
        if (k === 0) {
            flag = !flag
        }
        if (flag) {
            k = n - 1 - k
        }
        box_map[k].push(input_str[i])
    }
    for (let i=0;i<n;i++){
         console.log(box_map[i].join(""))
    }
}
 
 
main("ABCDEFG" ,3)