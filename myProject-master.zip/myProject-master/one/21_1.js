// 字符串解密  满分
// 解题思路：
// 根据题意：
// string1的子串要求：
// 1、只包含字母 g - z
// 2、且子串中不同字母的数量小于等于string2中的不同字母数量
// 求字符串中不同字母数量可以使用set，set可以去重，set的长度则为不同字母的数量。

const rl = require("readline").createInterface({
    input: process.stdin,
    output: process.stdout,
});
var iter = rl[Symbol.asyncIterator]();
const readline = async () => (await iter.next()).value;
void (async function () {
    let s1 = await readline();
    let s2 = await readline();
    var vis = new Array(200).fill(0);
    for (let i = 0; i < s2.length; i++) {
        vis[s2.charCodeAt(i)] += 1;
    }
    var num = 0;
    for (let i = 0; i < 200; i++) {
        if (vis[i] != 0) num += 1;
    }
    var p = "";
    var s = new Array();
    var Len = 0;
    for (let i = 0; i < s1.length; i++) {
        if ((s1[i] <= "9" && s1[i] >= "0") || (s1[i] <= "f" && s1[i] >= "a")) {
            if (p != "") s.push(p);
            p = "";
        } else {
            p += s1[i];
        }
    }
    if (p != "") s.push(p);
    let mx = -1;
    for (let i = 0; i < s.length; ++i) {
        let tmp = new Array(200).fill(0);
        for (let j = 0; j < s[i].length; ++j) {
            tmp[s[i].charCodeAt(j)] = 1;
        }
        let now = 0;
        for (let j = 0; j < 200; ++j) {
            if (tmp[j]) now += 1;
        }
        if (now <= num) mx = Math.max(mx, now);
    }
    if (mx == -1) {
        console.log("Not Found");
    }
    let res = "";
    for (let i = 0; i < s.length; ++i) {
        let tmp = new Array(200).fill(0);
        for (let j = 0; j < s[i].length; ++j) {
            tmp[s[i].charCodeAt(j)] = 1;
        }
        let now = 0;
        for (let j = 0; j < 200; ++j) {
            if (tmp[j]) now += 1;
        }
        if (now == mx) {
            if (s[i] > res) res = s[i];
        }
    }
    console.log(res);
})();