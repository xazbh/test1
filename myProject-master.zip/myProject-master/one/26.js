// 箱子之字形摆放  100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
rl.on("line", (line) => {
  const [str, n] = line.split(" ");
  getResult(str, n - 0);
});
 
function getResult(str, n) {
  const len = str.length;
 
  const matrix = new Array(n).fill(0).map(() => new Array());
 
  let reverse = true;
  for (let i = 0; i < len; i++) {
    k = i % n;
    if (k === 0) reverse = !reverse;
    if (reverse) k = n - 1 - k;
    matrix[k].push(str[i]);
  }
 
  matrix.forEach((arr) => console.log(arr.join("")));
}