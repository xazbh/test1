// 通信误码  90%


/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 2) {
    const total = lines[0] - 0;
    const arr = lines[1].split(" ").map(Number);
 
    console.log(getResult(total, arr));
 
    lines.length = 0;
  }
});
 
/**
 *
 * @param {*} total 误码总数目
 * @param {*} arr 误码出现频率数组
 */
function getResult(total, arr) {
  const idxs = {};
 
  for (let i = 0; i < arr.length; i++) {
    const code = arr[i];
    idxs[code] ? idxs[code].push(i) : (idxs[code] = [i]);
  }
 
  const countArr = Object.values(idxs).sort((a, b) => {
    if (a.length !== b.length) {
      return b.length - a.length;
    } else {
      const alen = a.at(-1) - a.at(0);
      const blen = b.at(-1) - b.at(0);
      return alen - blen;
    }
  });
 
  const start = countArr[0].at(0);
  const end = countArr[0].at(-1);
  return end - start + 1;
}