//查找单入口空闲区域 ?
/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
let n, m;
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 1) {
    [n, m] = lines[0].split(" ").map(Number);
  }
 
  if (n && lines.length === n + 1) {
    lines.shift();
    const matrix = lines.map((line) => line.split(" "));
    console.log(getResult(matrix, n, m));
    lines.length = 0;
  }
});
 
function getResult(matrix, n, m) {
  const checked = new Set();
 
  const offset = [
    [0, -1],
    [0, 1],
    [-1, 0],
    [1, 0],
  ];
 
  function dfs(i, j, count, out) {
    const pos = `${i}-${j}`;
 
    if (
      i < 0 ||
      i >= n ||
      j < 0 ||
      j >= m ||
      matrix[i][j] === "X" ||
      checked.has(pos)
    )
      return count;
 
    checked.add(pos);
 
    if (i === 0 || i === n - 1 || j === 0 || j === m - 1) out.push([i, j]);
 
    count++;
 
    for (let k = 0; k < offset.length; k++) {
      const [offsetX, offsetY] = offset[k];
      const newI = i + offsetX;
      const newJ = j + offsetY;
      count = dfs(newI, newJ, count, out);
    }
 
    return count;
  }
 
  const ans = [];
 
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < m; j++) {
      if (matrix[i][j] === "O" && !checked.has(`${i}-${j}`)) {
        const out = [];
        const count = dfs(i, j, 0, out);
        if (out.length === 1) {
          ans.push([...out[0], count]);
        }
      }
    }
  }
 
  if (!ans.length) return "NULL";
 
  ans.sort((a, b) => b[2] - a[2]);
 
  if (ans.length === 1 || ans[0][2] > ans[1][2]) {
    return ans[0].join(" ");
  } else {
    return ans[0][2];
  }
}