// 核酸最快检测效率  100%  No.65

function main(sample_num, volunteer_num, efficiencys) {
    // 按效率排序，因为要先给效率最高的采样员配备志愿者
    let range_efficiencys = new Array(sample_num);
    for (let i = 0; i < sample_num; i++) {
        range_efficiencys[i] = efficiencys[i]/10;  
    }
    let dp = new Array(sample_num+1)
    for (let i = 0; i <= sample_num; i++) {
        dp[i] = new Array(volunteer_num+1).fill(0)
    }
    let count = 0;
    for (let i = 1; i < sample_num+1; i++) {
        count += (efficiencys[i-1] - 2*range_efficiencys[i-1]);
        dp[i][0] = count;   
    }
 
    for (let i = 1; i < sample_num+1; i++) {  
        for (let j = 1; j < volunteer_num+1; j++) {     
            dp[i][j] = Math.max( dp[i-1][j]+efficiencys[i-1]-2*range_efficiencys[i-1], dp[i-1][j-1]+efficiencys[i-1]);     //志愿者大于等于1
            dp[i][j] = Math.max( dp[i][j], j-2 >= 0 ? dp[i-1][j-2]+efficiencys[i-1]+range_efficiencys[i-1] : 0);    //志愿者大于等于2
            dp[i][j] = Math.max( dp[i][j], j-3 >= 0 ? dp[i-1][j-3]+efficiencys[i-1]+2*range_efficiencys[i-1] : 0);  //志愿者大于等于3
            dp[i][j] = Math.max( dp[i][j], j-4 >= 0 ? dp[i-1][j-4]+efficiencys[i-1]+3*range_efficiencys[i-1] : 0);  //志愿者大于等于4
        }
    }
    console.log(dp[sample_num][volunteer_num])
 
}
 
 
main(2, 2,[200, 200])