// 计算数组中心位置  100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
rl.on("line", (line) => {
  const arr = line.split(" ").map(BigInt);
 
  let left = 1n;
  let right = arr.reduce((p, c) => p * c) / arr[0];
 
  if (left === right) {
    return console.log(0);
  }
 
  for (let i = 1; i < arr.length; i++) {
    left *= arr[i - 1];
    right /= arr[i];
 
    if (left === right) return console.log(i);
  }
 
  return console.log(-1);
});