//最短木板长度 100%
/* JavaScript Node ACM模式 控制台输入获取 */
// 动态规划
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 2) {
    const [n, m] = lines[0].split(" ").map(Number);
    const arr = lines[1].split(" ").map(Number);
    console.log(getResult(n, m, arr));
 
    lines.length = 0;
  }
});
 
/**
 * @param {*} n 木板数量
 * @param {*} m 可用的木料长度
 * @param {*} arr 木板长度数组
 * @returns 最短木板长度
 */
function getResult(n, m, arr) {
  // 木板长度升序
  arr.sort((a, b) => a - b);
 
  // dp用于保存将所有arr[i-1]长度的木板补足到arr[i]长度，所需要的木料长度
  let dp = 0;
  for (let i = 1; i < n; i++) {
    // 比如将arr[0]长度的木板补足到arr[1]所需的木料长度为arr[1] - arr[0]
    // 比如将arr[1]长度的木板补足到arr[2]所需的木料长度为(arr[2] - arr[1]) * 2，注意这里*2的原因是arr[0]已经被补足到arr[1]长度了，因此arr[1]长度此时有2个
    const need = (arr[i] - arr[i - 1]) * i;
 
    // 如果m可用木料不满足上面，则将剩余可用m-dp的材料均分给i根木料，返回此时的最短木料
    if (dp + need > m) {
      return Math.floor((m - dp) / i) + arr[i - 1];
    }
 
    dp += need;
  }
 
  // 如果将所有木板都补足到最长木板的长度了，还有剩余木料可用，则均分
  return Math.floor((m - dp) / n) + arr.at(-1);
}