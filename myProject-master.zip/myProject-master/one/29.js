// 挑选字符串  100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 2) {
    console.log(getResult(lines[0], lines[1]));
    lines.length = 0;
  }
});
 
function getResult(a, b) {
  // idxs对象记录字符串b中每个字符的索引
  const idxs = {};
  for (let i = 0; i < b.length; i++) {
    idxs[b[i]] = i;
  }
 
  // count对象用于记录遍历字符串a每个字符串过程中，统计到的符合顺序要求的字符串b中字符出现次数
  const count = new Array(b.length).fill(0);
 
  for (let c of a) {
    const idx = idxs[c];
    // 下面判断逻辑请看图解
    if (idx !== undefined && (idx === 0 || count[idx] < count[idx - 1])) {
      count[idx]++;
    }
  }
 
  return count.at(-1);
}