// 查找单入口空闲区域  100%

//JSRUN引擎2.0,支持多达30种语言在线运行,全仿真在线交互输入输出。
let directions = [[0, -1],[0, 1],[-1, 0],[1, 0]];
let visited = new Set();
 
function main(m, n, matrix_strs) {
    let matrix = []
    for (let str of matrix_strs) {
        matrix.push(str.split(" "))
    }
    let result = []
    
    for (let i = 0; i < m; i++) {
        for (let j = 0; j < n; j++) {
            let position = i.toString() + j.toString()
            if (matrix[i][j] === "O" && !visited.has(position)) {
                let temp_res = [];
                let count = dfs(m,n,i, j, 0, temp_res,matrix);
                if (temp_res.length === 1) {
                    result.push([...temp_res[0], count]);
                }
            }
        }
    }
    
    if (!result.length) {
        console.log("NULL")
    } else {
        result.sort(function(a, b) {
            return b[2] - a[2]
        });
    
        if (result.length === 1 || result[0][2] > result[1][2]) {
            console.log(result[0].join(" "))
        } else {
            console.log(result[0][2])
        }
    }
    
    
}
function dfs(m,n,i, j, count, temp_res,matrix) {
    let position = i.toString() + j.toString()
 
    if (i < 0 || i >= m || j < 0 ||j >= n || matrix[i][j] === "X" || visited.has(position)) {
        return count;
    }
 
    if (i === 0 || i === m - 1 || j === 0 || j === n - 1) {
        temp_res.push([i, j]);
    }
    visited.add(position)
    
    count++;
    for (let direction of directions) {
        let new_x = i + direction[0];
        let new_y = j + direction[1];
        count = dfs(m,n,new_x, new_y, count, temp_res,matrix);
    }
 
    return count;
}
 
 
main(5,4,["X X X X","X O O O","X X X X","X O O O","X X X X"])