// 微服务的集成测试  满分

/** 
解题思路：
通过回溯的方法获取最终启动的服务所依赖的所有服务的启动的时间。

这道题比较难，正确率只有8%。

如示例3：

4

2 0 0 0

0 3 0 0

1 1 4 0

1 1 1 5

4

首先遍历第四行，index=3，times3={}

当i=0时，ints[3][0]==1，依赖服务1，times0={}；

遍历第一行，因为不依赖其他服务，所以最终time0={}，返回0+2;

当i=1时，ints[3][1]==1，依赖服务2，times1={}；

遍历第二行，因为不依赖其他服务，所以最终time1={}，返回0+3;

当i=2时，ints[3][2]==1，依赖服务3，times2={}；

遍历第三行，因为服务1和服务2，所以最终time2={2，3}，取其中最大值3，返回3+4=7;

遍历完成，最终times3={2，3，7}，取其中最大值7，返回7+5=12；

最终结果12。
*/

//let n = Number(readline());
let n = Number("4");
let nums = [];
let test = [
    "2 0 0 0",
    "0 3 0 0",
    "1 1 4 0",
    "1 1 1 5"
];
for (let i = 0; i < n; i++) {
    //nums[i] = readline().split(" ").map(Number);
    nums[i] = test[i].split(" ").map(Number);
}
//let k = Number(readline());
let k = Number("4");
let count = 0;
count = dfs(nums, k-1);
console.log(count);
 
function dfs( nums, k) {
    let max = 0;
    for (let i = 0; i < nums.length; i++) {
        if (nums[k][i] != 0 && i != k){
            max = Math.max(max, dfs(nums,i));
        }
    }
    return max + nums[k][k];
}