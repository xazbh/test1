// 单向链表中间节点  预计100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
let head;
let n;
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 1) {
    [head, n] = lines[0].split(" ");
  }
 
  if (n && lines.length === n - 0 + 1) {
    lines.shift();
 
    const nodes = {};
 
    lines.forEach((line) => {
      const [addr, val, nextAddr] = line.split(" ");
      nodes[addr] = [val, nextAddr];
    });
 
    console.log(getResult(head, nodes));
 
    lines.length = 0;
  }
});
 
function getResult(head, nodes) {
  const linkedlist = [];
 
  let node = nodes[head];
  while (node) {
    const [val, next] = node;
 
    linkedlist.push(val);
    node = nodes[next];
  }
 
  const len = linkedlist.length;
 
  const mid = len % 2 === 0 ? len / 2 : Math.floor(len / 2);
 
  return linkedlist[mid];
}