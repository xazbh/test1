//日志采集系统 满分
const rl = require("readline").createInterface({ input: process.stdin });
var iter = rl[Symbol.asyncIterator]();
const readline = async () => (await iter.next()).value;
 
void (async function () {
    // Write your code here
    while ((line = await readline())) {
        let logArr = line.split(" ").map(Number);
        let ans = 0;
        let total = 0;
        let preTotal = 0;
        let koufen = 0;
        for (let i = 0; i < logArr.length; i++) {
            preTotal = total;
            total += logArr[i];
            if (total >= 100) {
                total = 100;
                koufen += preTotal;
                ans = Math.max(ans, total - koufen);
                break;
            }
            koufen += preTotal;
            ans = Math.max(ans, total - koufen);
        }
        console.log(ans);
    }
})();