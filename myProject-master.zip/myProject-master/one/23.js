// 任务总执行时长  100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
rl.on("line", (line) => {
  const [taskA, taskB, num] = line.split(",").map(Number);
  console.log(getResult(taskA, taskB, num));
});
 
function getResult(taskA, taskB, num) {
  if (num == 0) return [];
 
  if (taskA === taskB) {
    return [taskA * num];
  }
 
  const ans = new Set();
  for (let i = 0; i <= num; i++) {
    ans.add(taskA * i + taskB * (num - i));
  }
 
  return [...ans].sort((a, b) => a - b);
}