// 光伏场地建设规划  满分

/** 
解题思路：
通过四层for循环来获取每个发电区域的发电量，再判断发电量是否满足最低要求发电量。（不要担心时间复杂度，这是满分答案）
*/

// 本题为考试多行输入输出规范示例，无需提交，不计分。
var readline = require('readline');
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    terminal:false
});
 
let n = 0
let w
let h
let b
let min
let res = 0
const map = []
 
rl.on('line', function(line){ // javascript每行数据的回调接口
   const l = line.trim()
   n++
   if (n === 1) {
       const ll = l.split(' ')
       w = ll[0] *1
       h = ll[1] *1
       b = ll[2] *1
       min = ll[3] *1
   } else {
       map.push(l.split(' ').map(item => item * 1))
       if (n === w + 1) {
           for (let i = 0; i <= w - b ;i ++) {
               for (let j = 0; j <= h - b ; j ++) {
                   let t = 0
                   for (let x = 0; x < b; x ++) {
                       for (let y = 0; y < b; y ++) {
                           let _x = i+x
                           let _y = j+y
                           let num = map[_x][_y]
                           t += num
                       }
                   }
                   if (t >= min) res ++
               }
           }
           console.log(res)
       }
   }
});