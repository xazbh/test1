//获取最大软件版本号  满分
// 解题思路：
// 将输入的版本号转化为长度为4的字符串数组（没有值的用空字符代替）
// 前面两个字符直接转化为int类型进行比较；
// 第三个字符如果两个都有值，则转化为int进行比较；
//                   如果都为空，则表示相等；
//                   如果一个为空，则另一个为大；
// 第四个字符直接作为字符串进行比较。
const readline = require('readline');
 
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});
 
const data = [];
const handle = (arr) => {
//     console.log(arr);
    const first = arr[0];
    const second = arr[1];
    
    for(let i = 0; i < 2; i++) {
        if(Number(first[i]) > Number(second[i])) {
            console.log(first.join('.'));
            return;
        } else if(Number(first[i]) < Number(second[i]))  {
            console.log(second.join('.'));
            return;
        }
    }
    
    const firstSet = first[2] ? first[2].split('-') : '0';
    const secondSet = second[2] ? second[2].split('-') : '0';
    const len = Math.max(firstSet.length, secondSet.length)
    
    const res = [firstSet, secondSet];
    for(let i = 0; i < len; i++) {
        firstSet[i] = firstSet[i] ? firstSet[i] : '0';
        secondSet[i] = secondSet[i] ? secondSet[i] : '0';
        if(firstSet[i] > secondSet[i]) {
            console.log(first.join('.'));
            return;
        } else if(firstSet[i] < secondSet[i]) {
            console.log(second.join('.'));
            return;
        }
    }
    
//      console.log(res);
 
    console.log(first.join('.'));
    
}
 
rl.on('line', function (line) {
    data.push(line.split('.'));
    if(data.length === 2) {
        handle(data)
    }
});