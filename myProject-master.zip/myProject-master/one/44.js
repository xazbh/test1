// 新员工座位  ？

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
rl.on("line", (line) => {
  const arr = line.split(" ");
  console.log(getResult(arr));
});
 
function getResult(arr) {
  // 记录空位的友好度
  const ep = {};
 
  let friendShip = 0;
  // 从左向右遍历，记录每个空位左边的友好度
  for (let i = 0; i < arr.length; i++) {
    switch (arr[i]) {
      case "0":
        ep[i] = friendShip;
        friendShip = 0;
        break;
      case "1":
        friendShip++;
        break;
      case "2":
        friendShip = 0;
        break;
    }
  }
 
  friendShip = 0;
  let ans = 0;
  // 从右向左遍历，累加每个空位右边的友好度，这样就得到了每个空位的友好度，取最大值即可
  for (let i = arr.length - 1; i >= 0; i--) {
    switch (arr[i]) {
      case "0":
        ans = Math.max(ans, ep[i] + friendShip);
        friendShip = 0;
        break;
      case "1":
        friendShip++;
        break;
      case "2":
        friendShip = 0;
        break;
    }
  }
 
  return ans;
}