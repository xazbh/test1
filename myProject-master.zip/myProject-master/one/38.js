// 密室逃生游戏  100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 2) {
    const key = lines[0];
    const boxes = lines[1].split(" ");
    console.log(getResult(key, boxes));
 
    lines.length = 0;
  }
});
 
/**
 * @param {*} key 升序的不重复小写字母组成的密码K
 * @param {*} boxes 数组，元素box为字符串
 * @returns 包含key的忽略大小写的所有字母的box
 */
function getResult(key, boxes) {
  for (let i = 0; i < boxes.length; i++) {
    const box = boxes[i];
    const tmp = [...box.replace(/[^a-zA-Z]/g, "").toLowerCase()]
      .sort()
      .join("");
 
    if (key == tmp) {
      return i + 1;
    }
  }
  return -1;
}