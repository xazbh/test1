// 发现新词的数量 /新词挖掘  100%

function main(content, word){
    if ((content.length < word.length) || (word.length=0)) {
        console.log(0)
        return
    }
 
    let content_map = {}
    let word_map = {}
    //先统计出word中的字符组成
    for (let i=0;i<word.length;i++) {
        if (word[i] in word_map) {
            word_map[word[i]] += 1
        }
        else{
            word_map[word[i]] = 1
        }
    }
 
    let word_char_kind = Object.keys(word_map).length
    let right = 0
    let content_child_char_kind = 0
    let result = 0
    while(right < content.length){
        if(right >= word.length){
            left = right - word.length
            if (content[left] in word_map && content_map[content[left]] == word_map[content[left]]) {		
                content_child_char_kind -= 1
            }
            content_map[content[left]] -= 1
        }
        if (content[right] in content_map) {
            content_map[content[right]] += 1
        }
        else{
            content_map[content[right]] = 1
        }
 
        if (content[right] in word_map && content_map[content[right]] == word_map[content[right]]){
            content_child_char_kind+=1
        }
        right += 1
        if (content_child_char_kind == word_char_kind){
            result += 1
        }
    }
    console.log(result)
}
 
main("qweebaewqd","qwe")