// 处理器问题  100%  No.100

//满足条件结果组合
let result = []
 
function dfs(batch_processor,index, level, path){
    if (path.length == level){
        result.push([...path])
        return 
    }
    
    
    for (let i=index;i<batch_processor.length;i++){
        path.push(batch_processor[i])
        // 逐个往后找合适的组合
        dfs(batch_processor, i + 1, level, path)
        path.pop()
    }
}
        
 
 
function get_combo(batch_processor, num){
    let path=[]
    dfs(batch_processor, 0, num, path)
}
 
function main(v, apply_num) {
 
 
    //初始化两个链路剩余可用的处理器
    let processors_1 = []
    let processors_2 = []
    for (let x of v){
        if (x >= 4)
            processors_2.push(x)
        else
            processors_1.push(x)
    }
    
    let length_1 = processors_1.length
    let length_2 = processors_2.length
 
 
 
    if (apply_num == 1){
        // 原则1
        if (length_1 == 1 || length_2 == 1){
            if (length_1 == 1)
                get_combo(processors_1, 1)
            if (length_2 == 1)
                get_combo(processors_2, 1)
        }
        else if (length_1 == 3 || length_2 == 3){
            if (length_1 == 3)
                get_combo(processors_1, 1)
            if (length_2 == 3)
                get_combo(processors_2, 1)
        }
        else if (length_1 == 2 || length_2 == 2){
            if (length_1 == 2)
                get_combo(processors_1, 1)
            if (length_2 == 2)
                get_combo(processors_2, 1)
        }
        else if (length_1 == 4 || length_2 == 4){
            if (length_1 == 4)
                get_combo(processors_1, 1)
            if (length_2 == 4)
                get_combo(processors_2, 1)
        }
    }
    else if (apply_num == 2){
        // 原则2
        if (length_1 == 2 || length_2 == 2){
            if (length_1 == 2)
                get_combo(processors_1, 2)
            if (length_2 == 2)
                get_combo(processors_2, 2)
        }
        else if (length_1 == 4 || length_2 == 4){
            if (length_1 == 4)
                get_combo(processors_1, 2)
            if (length_2 == 4)
                get_combo(processors_2, 2)
        }
        else if (length_1 == 3 || length_2 == 3){
            if (length_1 == 3)
                get_combo(processors_1, 2)
            if (length_2 == 3)
                get_combo(processors_2, 2)
        }
    }
    else if (apply_num == 4){
        // 原则3
        if (length_1 == 4 || length_2 == 4){
            if (length_1 == 4)
                result.push(processors_1)
            if (length_2 == 4)
                result.push(processors_2)
        }
    }   
    else if (apply_num == 8){
        // 原则4
        if (length_1 == 4 && length_2 == 4){
            processors_2 = processors_2 + processors_1
            result.push(processors_2)
        }
    }
    console.log(result)
 
}
 
 
main([0, 1, 4, 5, 6, 7], 1)