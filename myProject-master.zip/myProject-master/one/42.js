// 农场施肥  100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 2) {
    const [m, n] = lines[0].split(" ").map(Number);
    const fields = lines[1].split(" ").map(Number);
 
    console.log(getResult(n, fields));
    lines.length = 0;
  }
});
 
function getResult(n, fields) {
  let min = 1; // 最小果林面积
  let max = Math.max(...fields); // 最大果林面积
  let ans = -1;
 
  // 我们需要找min,max中间值作为k效率，如果min,max间距小于1，则没有中间值，循环结束
  while (min <= max) {
    let k = Math.ceil((min + max) / 2);
    const res = check(k, n, fields);
 
    if (res > 0)
      min = k + 1; // k的效率太低，导致花费的时间超过了n天，因此要提高k效率
    else {
      ans = k; // k的效率刚好，花费的时间就是n天，或者k的效率太高，导致花费的时间少于n天，而题目说：施肥任务必须在n天内（含n天）完成，因此花费时间少于n天的k也是符合要求的
      max = k - 1; // 继续尝试找更小的k
    }
  }
 
  return ans;
}
 
// k效率施肥完fields所有果林需要的spend天数，和指定天数n的差距
function check(k, n, fields) {
  let spend = 0;
  for (let field of fields) {
    if (k >= field) spend++; // k效率比field果林面积大，则field果林只需要一天
    else spend += Math.ceil(field / k); // k效率比field果林面积小，则需要Math.ceil(field / k)天
  }
 
  return spend - n;
}