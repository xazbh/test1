// 异常的打卡记录  满分
// 解题思路：
// 新建一个类来放置员工的打卡记录
// 遍历所有的打卡记录；
// 当注册设备号和打卡设备号不一致的时候直接异常（先判断这个）
// 或者两个打卡记录的时间小于60分钟并且打卡距离超过5km直接异常

//let n = Number(readline());
let n = Number("2");
let clockRecords = [];
//let test = ["100000,10,1,ABCD,ABCD","100000,50,10,ABCD,ABCD"];
//let test = ["100000,10,1,ABCD,ABCD","100000,80,10,ABCE,ABCD"];
let test = ["100000,10,1,ABCD,ABCD","100001,80,10,ABCE,ABCE"];
for(let i=0; i<n; i++){
    //let str = readline().split (",");
    let str = test[i].split (",");
    let yuanGong = new YuanGong (Number(str[0]),
            Number(str[1]),
            Number(str[2]),
            str[3],
            str[4]);
    yuanGong.error = isErrorData( str[3], str[4]);
    clockRecords.push(yuanGong);
}
 
for(let i=0; i<clockRecords.length; i++){
    for(let j=i+1; j<clockRecords.length; j++){
        if(clockRecords[i].id==clockRecords[j].id){
            let times=clockRecords[i].time-clockRecords[j].time;
            let diatances=clockRecords[i].distance-clockRecords[j].distance;
            times=times>0?times:times*(-1);
            diatances=diatances>0?diatances:diatances*(-1);
            if(times<60 && diatances>5){
                clockRecords[i].error = true;
                clockRecords[j].error = true;
            }
        }
    }
}
 
let str="";
for(let i=0; i<clockRecords.length; i++){
    if(clockRecords[i].error){
        str += toString (clockRecords[i])+" ";
    }
}
if(str.length == 0){
    console.log("null");
}else {
    console.log(str.trim().replace(" ",";"));
}
 
function YuanGong( id, time, distance, actualDeviceNumber, registeredDeviceNumber) {
    this.id = id;
    this.time = time;
    this.distance = distance;
    this.actualDeviceNumber = actualDeviceNumber;
    this.registeredDeviceNumber = registeredDeviceNumber;
    this.error=false;
}
 
function toString( yuanGong) {
    return "" + yuanGong.id + "," + yuanGong.time + "," + yuanGong.distance + 
            "," + yuanGong.actualDeviceNumber  + "," + yuanGong.registeredDeviceNumber ;
}
 
function isErrorData( actualDeviceNumber, registeredDeviceNumber){
    if(actualDeviceNumber != registeredDeviceNumber){
        return true;
    }
    return false;
}