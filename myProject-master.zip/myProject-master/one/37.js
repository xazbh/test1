// 最长的密码  ?

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
rl.on("line", (line) => {
  const arr = line.split(" ");
 
  console.log(getResult(arr));
});
 
function getResult(arr) {
  arr.sort((a, b) =>
    a.length != b.length ? a.length - b.length : a == b ? 0 : a > b ? 1 : -1
  );
 
  const set = new Set(arr);
 
  while (arr.length) {
    const str = arr.pop();
 
    let end = str.length - 1;
    while (set.has(str.substring(0, end))) {
      if (end === 1) {
        return str;
      } else {
        end--;
      }
    }
  }
 
  return "";
}