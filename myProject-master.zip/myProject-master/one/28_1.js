// 最左侧冗余覆盖子串  满分

// 解题思路：
// 通过s1的长度和k值计算出父字符串的长度
// 从s2遍历中截取步骤1的长度的字符串作为父字符串
// 通过双层for循环，求出s1是否为步骤2中的子串

var s1=line = readline();
var s2=line = readline();
var k=parseInt(line = readline());
 
function main(){
    if(s1.length+k>s2.length){
        console.log(-1);
        return;
    }
 
    const map=new Map();
    for(let item of s1){
        map.set(item, map.has(item)? map.get(item)+1 : 1);
    }
 
    for(let i=0;i<s1.length+k;i++){
        if(map.has(s2[i])){
            map.set(s2[i], map.get(s2[i])-1);
        }
    }
    if(testMap(map)){
        console.log(0);
        return;
    }
 
    for(let i=s1.length+k;i<s2.length;i++){
        let j=i-s1.length-k;
        let pre=s2[j];
        if(map.has(pre)){
            map.set(pre, map.get(pre)+1);
        }
 
        let cur=s2[i];
        if(map.has(cur)){
            map.set(cur, map.get(cur)-1);
        }
 
        if(testMap(map)){
            console.log(j+1);
            return;
        }
    }
 
    console.log(-1)
}
 
function testMap(map){
    return [...map.values()].every(item=>{
        return !(item>0);
    })
}
 
main();
