//查找重复代码  100%
/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 2) {
    const str1 = lines[0];
    const str2 = lines[1];
    console.log(getResult(str1, str2));
    lines.length = 0;
  }
});
 
function getResult(str1, str2) {
  const n = str1.length;
  const m = str2.length;
 
  const dp = new Array(n + 1).fill(0).map(() => new Array(m + 1).fill(0));
 
  let max = 0;
  let ans = "";
 
  for (let i = 1; i <= n; i++) {
    for (let j = 1; j <= m; j++) {
      if (str1[i - 1] === str2[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1] + 1;
 
        if (dp[i][j] > max) {
          max = dp[i][j];
          ans = str1.slice(i - max, i);
        }
      } else {
        dp[i][j] = 0;
      }
    }
  }
 
  return ans;
}