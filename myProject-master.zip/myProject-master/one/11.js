// 完美走位  100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
rl.on("line", (line) => {
  console.log(getResult(line));
});
 
function getResult(str) {
  // 此时count记录统计W,A,S,D字母的数量
  const count = {
    W: 0,
    A: 0,
    S: 0,
    D: 0,
  };
 
  for (let c of str) count[c]++;
 
  // 平衡状态时，W,A,S,D应该都是avg数量
  const avg = str.length / 4;
 
  let total = 0; // total用于记录多余字母个数
 
  let flag = true; // flag表示当前是否为平衡状态，默认是
  for (let c in count) {
    if (count[c] > avg) {
      flag = false; // 如果有一个字母数量超标，则平衡打破
      count[c] -= avg; // 此时count记录每个字母超过avg的数量
      total += count[c];
    } else {
      delete count[c];
    }
  }
 
  if (flag) return 0; // 如果平衡，则输出0
 
  let i = 0;
  let j = 0;
  let minLen = str.length + 1;
 
  while (j < str.length) {
    const jc = str[j];
 
    if (count[jc]-- > 0) {
      total--;
    }
 
    while (total === 0) {
      minLen = Math.min(minLen, j - i + 1);
 
      const ic = str[i];
      if (count[ic]++ >= 0) {
        total++;
      }
 
      i++;
    }
 
    j++;
  }
 
  return minLen;
}