// 荒地建设电站  100%  No.81

//JSRUN引擎2.0,支持多达30种语言在线运行,全仿真在线交互输入输出。
function main(mat,threshold,c) {
    let m = mat.length
    let n = mat[0].length
    let P = new Array(m + 1)
    for (let i=0;i<m+1;i++) {
        P[i] = new Array(n+1).fill(0)
    }
 
    for (let i = 1; i < m+1; i++) {
        for (let j = 1; j < n+1; j++) {
            P[i][j] = P[i - 1][j] + P[i][j - 1] - P[i - 1][j - 1] + mat[i - 1][j - 1]
        }
    }
 
    let result = 0
    for (let i = c; i < m+1; i++) {
        for (let j = c; j < n+1; j++) {
            if (P[i][j] - P[i - c][j] - P[i][j - c] + P[i - c][j - c] >= threshold){
                result += 1
            }
        }
    }
    console.log(result)
}
 
main([[1, 3, 4, 5, 8],[2, 3, 6, 7, 1]],6,2)
 
 
 