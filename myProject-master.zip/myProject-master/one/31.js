// 优秀学员统计  ?

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 32) {
    const n = lines[0] - 0;
    const dayCount = lines[1].split(" ").map(Number);
    const dayIds = lines.slice(2).map((line) => line.split(" ").map(Number));
    console.log(getResult(dayIds));
 
    lines.length = 0;
  }
});
 
function getResult(dayIds) {
  const employees = {};
 
  for (let i = 0; i < dayIds.length; i++) {
    const ids = dayIds[i];
    for (let id of ids) {
      if (employees[id]) {
        employees[id].count++;
      } else {
        employees[id] = {
          count: 1,
          firstDay: i,
        };
      }
    }
  }
 
  let arr = [];
  for (let id in employees) {
    const { count, firstDay } = employees[id];
    arr.push([id, count, firstDay]);
  }
 
  arr.sort((a, b) =>
    b[1] !== a[1] ? b[1] - a[1] : b[2] !== a[2] ? a[2] - b[2] : a[0] - b[0]
  );
 
  return arr
    .slice(0, 5)
    .map(([id]) => id)
    .join(" ");
}