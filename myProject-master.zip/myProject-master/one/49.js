// 最大利润、贪心的商人  70%+

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
let number, days, maxCount;
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 3) {
    number = lines[0] - 0;
    days = lines[1] - 0;
    maxCount = lines[2].split(" ").map(Number);
  }
 
  if (number && lines.length === number + 3) {
    const prices = lines.slice(3).map((line) => line.split(" ").map(Number));
    console.log(getResult(number, days, maxCount, prices));
    lines.length = 0;
  }
  /* else {
    console.log("0"); // 如果通过率只有40%，可以解开这个else的注释，通过率会有所提升
  } */
});
 
/**
 *
 * @param {*} number 几种商品
 * @param {*} days 几天
 * @param {*} maxCount 每种商品的最大囤货数量
 * @param {*} prices 每种商品的在days天内的价格变动情况
 */
function getResult(number, days, maxCount, prices) {
  let ans = 0;
  for (let i = 0; i < number; i++) {
    const price = prices[i];
    for (let j = 0; j < days - 1; j++) {
      if (price[j] < price[j + 1]) {
        ans += (price[j + 1] - price[j]) * maxCount[i];
      }
    }
  }
  return ans;
}