// 星际篮球争霸赛  95%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 2) {
    const n = lines[0] - 0;
    const arr = lines[1].split(" ").map(Number);
 
    console.log(getResult(arr, n));
    lines.length = 0;
  }
});
 
function getResult(arr, n) {
  const sum = arr.sort((a, b) => b - a).reduce((p, c) => p + c);
 
  let count = n;
  while (count >= 1) {
    // 根据网友指正，由于canPartition方法中会删除arr元素，因此我们不能直接传递arr过去，需要传递arr备份，否则会影响下一次count判断
    // if (canPartition(arr, sum, count)) {
    if (canPartition([...arr], sum, count)) {
      return sum / count;
    } else {
      count--;
    }
  }
}
 
function canPartition(arr, sum, count) {
  if (sum % count) return false;
 
  let subSum = sum / count;
 
  if (subSum < arr[0]) return false;
 
  while (arr[0] === subSum) {
    arr.shift();
    count--;
  }
 
  const buckets = new Array(count).fill(0);
 
  return partition(0, arr, subSum, buckets);
}
 
function partition(index, arr, subSum, buckets) {
  if (index === arr.length) {
    return true;
  }
 
  const select = arr[index];
 
  for (let i = 0; i < buckets.length; i++) {
    if (i > 0 && buckets[i] === buckets[i - 1]) continue;
    if (buckets[i] + select <= subSum) {
      buckets[i] += select;
      if (partition(index + 1, arr, subSum, buckets)) return true;
      buckets[i] -= select;
    }
  }
 
  return false;
}