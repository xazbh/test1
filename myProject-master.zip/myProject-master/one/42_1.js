// 不爱施肥的小布  满分

/**
解题思路：
使用二分法。
获取最低能效l=1，获取最高能效（面积最大的果林）r=max
先取中间值mid =（l+r）/2，判断mid是否满足条件。
满足条件判断：ans为需要的天数。
遍历林园面积除以mid，若能整除则ans += 面积/mid，若不能整除，则ans += 面积/mid + 1；若ans<=m（规定天数），则满足，反之不满足。
若mid满足，则r=mid；如不满足，则l=mid+1；继续mid=（l+r）/2进行判断。以此类推，直至l>=r。
*/

// let input1 = readline().split(" ").map(Number);
// let fields = readline().split(" ").map(Number);
let input1 = "5 7".split(" ").map(Number);
let fields = "5 7 9 15 10".split(" ").map(Number);
 
let m = input1[0];
let n = input1[1];
//最低能效
let l = 1;
//最高能效
let r = Math.max(...fields);
while(l < r){
    //取中位数
    let mid = (l + r) / 2;
    //判断能效施肥满足天数要求
    if(check(mid, fields) <= n){
        //满足要求，右边界缩小
        r = mid;
    }else{
        //不满足，左边界缩小
        l = mid + 1;
    }
}
 
if(check(l, fields) > n){
    console.log(-1);
}else{
    console.log(l);
}
 
/**
 * 判断mid能效需要几天完成施肥
 * @param mid       能效
 * @param fields    面积数组
 * @return
 */
function check( mid, fields){
 
    let ans = 0;
    for(let i=0; i<fields.length; i++){
        //能整除能效则直接添加，否则需要+1
        if(fields[i] % mid == 0){
            ans += Math.floor(fields[i] / mid);
        }else{
            ans += Math.floor(fields[i] / mid) + 1;
        }
    }
    return ans;
}