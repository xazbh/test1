// 冗余覆盖  95%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 3) {
    const [s1, s2, k] = lines;
    console.log(getResult(s1, s2, k - 0));
    lines.length = 0;
  }
});
 
function getResult(s1, s2, k) {
  // 在s2中选一个子串，满足:该子串长度为 n1+k
  const n1 = s1.length;
  const n2 = s2.length;
  if (n2 < n1 + k) return -1;
 
  // 统计s1中所有每个字符出现的次数到count中
  const count = {};
  for (let c of s1) {
    count[c] ? count[c]++ : (count[c] = 1);
  }
 
  // s1字符总数
  let total = n1;
 
  // 滑动窗口的左边界从0开始，最大maxI；滑动窗口长度len
  const maxI = n2 - n1 - k;
  const len = n1 + k;
 
  // 统计s2的0~len范围内出现的s1中字符的次数
  for (let j = 0; j < len; j++) {
    const c = s2[j];
    // 如果s2的0~len范围内的字符c，在count[c]存在，则说明c是s1内有的字符，此时我们需要count[c]--，如果自减之前，count[c] > 0，则自减时，total也应该--,否则total不--
    if (count[c] !== undefined && count[c]-- > 0) {
      total--;
    }
 
    // 如果total为0了，则说明在s2的0~len范围内找到了所有s1中字符
    if (total === 0) {
      // 此时可以直接返回起始索引0
      return 0;
    }
  }
 
  // 下面是从左边界1开始的滑动窗口，利用差异思想，避免重复部分求解
  for (let i = 1; i <= maxI; i++) {
    // 滑动窗口右移一格后，失去了s2[i - 1]，得到了s2[i - 1 + len]，其余部分不变
    const remove = s2[i - 1];
    const add = s2[i - 1 + len];
 
    if (count[remove] !== undefined && count[remove]++ >= 0) {
      total++;
    }
 
    if (count[add] !== undefined && count[add]-- > 0) {
      total--;
    }
 
    if (total === 0) {
      return i;
    }
  }
 
  return -1;
}