// 网上商城优惠活动  ?


/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
let m, n, k, x;
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 1) {
    [m, n, k] = lines[0].split(" ").map(Number);
  }
 
  if (lines.length === 2) {
    x = parseInt(lines[1]);
  }
 
  if (x && lines.length === x + 2) {
    lines.shift();
    lines.shift();
 
    const arr = lines.map(Number);
 
    getResult(arr, m, n, k);
 
    lines.length = 0;
  }
});
 
/**
 *
 * @param {*} prices 几个人打折之前的商品总价
 * @param {*} m 满减券数量
 * @param {*} n 打折券数量
 * @param {*} k 无门槛券数量
 */
function getResult(prices, m, n, k) {
  for (let price of prices) {
    const ans = [];
 
    const resM = M(price, m); // 先满减
 
    const resMN_N = N(resM[0], n); // 满减后打折
    ans.push([resMN_N[0], m + n - (resM[1] + resMN_N[1])]); // resMN_N[0]是 “满减后打折” 的剩余总价， m + n - resM[1] - resMN_N[1] 是 该种用券方式的: 总券数 m+n， 剩余券数 resM[1] + resMN_N[1], 因此使用掉的券数： m+n - (resM[1] + resMN_N[1])
 
    const resMK_K = K(resM[0], k); // 满减后无门槛
    ans.push([resMK_K[0], m + k - (resM[1] + resMK_K[1])]);
 
    const resN = N(price, n); // 先打折
 
    const resNM_M = M(resN[0], m); // 打折后满减
    ans.push([resNM_M[0], n + m - (resN[1] + resNM_M[1])]);
 
    const resNK_K = K(resN[0], k); // 打折后无门槛
    ans.push([resNK_K[0], n + k - (resN[1] + resNK_K[1])]);
 
    ans.sort((a, b) => (a[0] === b[0] ? a[1] - b[1] : a[0] - b[0])); // 对ans进行排序，排序规则是：优先按剩余总价升序，如果剩余总价相同，则再按“使用掉的券数量”升序
 
    console.log(ans[0].join(" "));
  }
}
 
/**
 * @param {*} price 总价
 * @param {*} m 满减券数量
 * @returns 总价满减后结果，对应数组含义是 [用券后剩余总价， 剩余满减券数量]
 */
function M(price, m) {
  const maxCount = price / 100; // 满100最多用1张满减券，满200最多用2张满减券....，price总价最多使用price/100张券
  const count = Math.min(m, maxCount); // 实际可使用的满减券数量
 
  price -= count * 10;
  m -= count;
 
  return [price, m];
}
 
/**
 * @param {*} price 总价
 * @param {*} n 打折券数量
 * @returns 总价打折后结果，对应数组含义是 [用券后剩余总价， 剩余打折券数量]
 */
function N(price, n) {
  if (n >= 1) {
    price = Math.floor(price * 0.92);
  }
  return [price, n - 1];
}
 
/**
 * @param {*} price 总价
 * @param {*} k 无门槛券数量
 * @returns 无门槛券用后结果，对应数组含义是 [用券后剩余总价， 剩余无门槛券数量]
 */
function K(price, k) {
  while (price > 0 && k > 0) {
    price -= 5;
    price = Math.max(price, 0); // 无门槛券过多会导致优惠后总价小于0，此时我们应该避免
    k--;
  }
  return [price, k];
}