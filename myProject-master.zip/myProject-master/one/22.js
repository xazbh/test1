// 投篮大赛  100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
rl.on("line", (line) => {
  const ops = line.split(" ");
  console.log(getResult(ops));
});
 
function getResult(ops) {
  // ans用于保存每轮的得分
  const ans = [];
 
  const reg = /^\-?\d+$/;
  for (let op of ops) {
    // 如果op是整数，则表示本轮得分，直接加入ans
    if (reg.test(op)) {
      ans.push(op - 0);
    } else {
      switch (op) {
        // 如果op是+，则表示本轮得分是前两轮得分之和，注意越界处理
        case "+":
          if (!ans.at(-1) || !ans.at(-2)) return -1;
          ans.push(ans.at(-1) + ans.at(-2));
          break;
        // 如果op是D，表示本轮得分是前一轮得分的双倍，注意越界处理
        case "D":
          if (!ans.at(-1)) return -1;
          ans.push(ans.at(-1) * 2);
          break;
        // 如果op是C，则表示本轮无得分，且上一轮得分无效，需要去除
        case "C":
          if (!ans.at(-1)) return -1;
          ans.pop();
          break;
      }
    }
  }
 
  // 感谢网友m0_71826536提示，如果用例输入为：2 C，则此处会报错
  // return ans.reduce((p, c) => p + c);
 
  if (ans.length) return ans.reduce((p, c) => p + c);
  else return 0;
}