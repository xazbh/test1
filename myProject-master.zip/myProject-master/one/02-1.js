// 满分  木板
// let input1 = readline().split(" ").map(Number);
// let arr = readline().split(" ").map(Number);
let input1 = "5 3".split(" ").map(Number);
let arr = "4 5 3 5 5".split(" ").map(Number);
//物料长度
const len = input1[1];
arr.sort();
//动态计算
for (let i = 0; i < len; i++) {
    for (let j = 0; j < arr.length; j++) {
        if (j + 1 < arr.length && arr[j] + 1 > arr[j + 1]) {
            continue;
        }
        arr[j]++;
        break;
    }
}
 
console.log(arr[0]);

