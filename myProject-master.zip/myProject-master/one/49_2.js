// 最大利润  贪心商人  100%  No.23

//JSRUN引擎2.0，支持多达30种语言在线运行，全仿真在线交互输入输出。
function main(number, days, items, prices) {
  let max_profit = 0
  for (let i = 0; i < number; i++) {
    const price = prices[i];
    for (let j = 0; j < days - 1; j++) {
      if (price[j] < price[j + 1]) {
        max_profit += (price[j + 1] - price[j]) * items[i]
      }
    }
  }
  console.log(max_profit)
}
 
 
main(3,3,[4, 5, 6], [[1, 2, 3],[4, 3, 2], [1, 5, 3]])