// 最多提取子串数目  满分

// 解题思路：
// 如示例4：
// 父字符串：ababcecfdc   父索引indexF=0
// 子字符串：abc                  子索引indexS=0
// indexF=0, indexS=0    a == a;
// indexF+1=1, indexS+1=1    b == b
// indexF+1=2, indexS+1=2     a  != c
// indexF+1=3, indexS=2        b ! = c
// indexF+1=4, indexS=2        c == c
// 满足子串  父字符串变为：ab ecfdc（匹配过的需要用空字符串替代）
// indexF=0, indexS=0    a == a; 
// 继续重复上面操作，直至indexF=父字符串长度-1

const rl = require("readline").createInterface({ input: process.stdin });
var iter = rl[Symbol.asyncIterator]();
const readline = async () => (await iter.next()).value;
 
void (async function () {
  // Write your code here
  let aline=await readline()
  let bline=await readline()
  let alist=aline.split('')
  let blist=bline.split('')
  let count=0
  let n=1
  while(n){
      let temp=[]
      let stack=[...blist]
      for(let i=0;i<alist.length;i++){
          if(stack.length==0){
              break
          }
          if(alist[i]==stack[0]){
            stack.shift()
            temp.push(i)
          }
    }
      if(stack.length==0){
          count++
          while(temp.length>0){
              let j=temp.pop()
              alist.splice(j,1)
          }
      }
      else{
          n=0
      }
  }
  console.log(count)
})();