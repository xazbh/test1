// 星际篮球争霸赛  100% No.26

//JSRUN引擎2.0，支持多达30种语言在线运行，全仿真在线交互输入输出。
function canPartitionKSubsets(nums, k) {
    if(k > nums.length) return false
    nums = nums.sort((a,b)=> b - a)
    const buckts = new Array(k).fill(0)
    const sum = nums.reduce((acc, cur) => acc + cur)
    if(sum % k !== 0) return false
    const target = sum / k
    let fn = (nums, index, buckts, target) => {
        if (index === nums.length) {
            for(let i = 0; i < k; i++){
                if(buckts[i] !== target){
                    return false
                }
                return true
            }
            
        }
        for (let i = 0; i < k; i++) {
            if (buckts[i] + nums[index] > target) continue
            buckts[i] += nums[index]
            if (fn(nums, index + 1, buckts, target)) {
                return true
            }
            buckts[i] -= nums[index]
        }
        return false
    }
    return fn(nums, 0, buckts, target)
}
 
 
function main(m, nums) {
    let sum=nums.sort((a, b) => b - a).reduce((p, c) => p + c);
    for (let i=m;i>0;i--) {
        //从最大的可能行开始，满足条件即为为最小的情况
        if (canPartitionKSubsets(nums, i)) {
            console.log(sum / i);
            break;
        }
    }
 
}
 
main(9, [5, 2, 1, 5, 2 ,1,5 ,2, 1])
 
 