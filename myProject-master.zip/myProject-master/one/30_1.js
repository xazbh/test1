// 找出通过车辆最多颜色  满分

// 解题思路：
// 题目规定只有3种颜色。我们可以使用长度为3的整数数组表示。
// 当颜色为0，ints[0]++;
// 当颜色为1，ints[1]++;
// 当颜色为2，ints[2]++;

var lines = readline().split(" ").map(Number);
var n = parseInt(readline());
var arr = [];
if (n >= lines.length) {
    let a = {};
    for (var j = 0; j < lines.length; j++) {
        if (a[lines[j]]) {
            a[lines[j]]++;
        } else {
            a[lines[j]] = 1;
        }
    }
    console.log(Math.max(...Object.values(a)));
} else {
    for (var j = 0; j < lines.length; j++) {
        if (j + n > lines.length) break;
        let a = {};
        for (var i = 0; i < n; i++) {
            if (a[lines[i + j]]) {
                a[lines[i + j]]++;
            } else {
                a[lines[i + j]] = 1;
            }
        }
        arr.push(Math.max(...Object.values(a)));
    }
    console.log(Math.max(...arr));
}