// 微服务的集成测试  预计100% 

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
let n;
let cache;
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 1) {
    n = lines[0] - 0;
  }
 
  if (n && lines.length === n + 2) {
    lines.shift();
    const k = lines.pop();
    const matrix = lines.map((line) => line.split(" ").map(Number));
    cache = new Array(n);
    console.log(getResult(matrix, k));
    lines.length = 0;
  }
});
 
function getResult(matrix, k) {
  return dfs(k - 1, matrix);
}
 
function dfs(k, matrix) {
  // cache用于记录每个服务所需要时间，避免多个子服务依赖同一个父服务时，对父服务启动时间的重复递归求解
  if (cache[k] != undefined) return cache[k];
 
  const preK = matrix[k];
 
  let maxPreTime = 0;
  for (let i = 0; i < preK.length; i++) {
    if (i != k && preK[i] != 0) {
      maxPreTime = Math.max(maxPreTime, dfs(i, matrix));
    }
  }
 
  cache[k] = matrix[k][k] + maxPreTime;
 
  return cache[k];
}