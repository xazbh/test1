// 微服务的集成测试  100%  No.96

function dfs(k,  service_map, dp) {
    let time = 0;
    for (let i=0;i< service_map[k].length;i++) {
        if (i != k && service_map[k][i] != 0) {
                if (dp[i + 1] > 0)
                    time = Math.max(time, dp[i + 1]);
                else
                    time = Math.max(time, dfs(i, service_map, dp));
            }
            dp[k + 1] = time + service_map[k][k];
    }
 
    return service_map[k][k] + time;
}
 
function main(service_map, target) {
    let dp = new Array(service_map[0].length+1).fill(0);
    console.log(dfs(target-1,service_map, dp));
}
 
 
main([[5, 0, 0],[1, 5, 0],[0, 1, 5]], 3)
