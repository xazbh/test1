// 积木最远距离  100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
let n;
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 1) {
    n = lines[0] - 0;
  }
 
  if (n && lines.length === n + 1) {
    lines.shift();
    const arr = lines.map(Number);
    console.log(getResult(arr));
 
    lines.length = 0;
  }
});
 
function getResult(nums) {
  const idx = {};
 
  for (let i = 0; i < nums.length; i++) {
    const num = nums[i];
    idx[num] ? idx[num].push(i) : (idx[num] = [i]);
  }
 
  let ans = -1;
  for (let k in idx) {
    if (idx[k].length > 1) {
      ans = Math.max(ans, idx[k].at(-1) - idx[k][0]);
    }
  }
 
  return ans;
}