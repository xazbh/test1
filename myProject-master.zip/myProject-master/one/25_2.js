// 整理扑克牌 100%

function main(card_str) {
    let cards = card_str.split(" ").map(Number)
    let card_count = {}
 
    for (let num of cards) {
        card_count[num] ? card_count[num]++ : (card_count[num] = 1)
    }
    let card_type = {4: [],"3+2": [],3: [],2: [],1: []}
    
    for (let card in card_count) {
        if (card_count[card] == 3) 
            card_type[3].push(card)
        else if (card_count[card] == 2) 
            card_type[2].push(card)
        else if (card_count[card] == 1)
            card_type[1].push(card)
        else
            card_type[4].push([card, card_count[card]]) 
    }
    
    
    // 排序
    card_type[4].sort(function (a, b){
        return b[0] * b[1] - a[0] * a[1]
    })
    card_type[3].sort((a, b) => b - a)
    card_type[2].sort((a, b) => b - a)
 
    while (card_type[3].length) {
        if (card_type[2].length === 0 && card_type[3].length === 1)
            break
 
        let san_top = card_type[3].shift()
    
        let tmp
        if (card_type[2].length === 0 ||(card_type[3].length >= 1 && card_type[3][0] > card_type[2][0])) {
            tmp = card_type[3].shift()
            card_type[1].push(tmp)
        } else {
            tmp = card_type[2].shift()
        }
        card_type["3+2"].push([san_top, tmp])
    }
    card_type[1].sort((a, b) => b - a)
    
    let result = []
    
    for (let card of card_type[4]) {
        result.push(...new Array(card[1]).fill(card[0]))
    }
    for (let card of card_type["3+2"]) {
        let [san, er] = card
        result.push(...new Array(3).fill(card[0]), ...new Array(2).fill(card[1]))
    }
    for (let card of card_type[3]) {
        result.push(...new Array(3).fill(card))
    }
    
    for (let card of card_type[2]) {
        result.push(...new Array(2).fill(card))
    }
 
    result.push(card_type[1])
    
    console.log(result.join(" "))
}
 
main("4 4 2 1 2 1 3 3 3 4")

