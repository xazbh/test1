//猜字谜 100%
/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 2) {
    const issues = lines[0].split(",");
    const answers = lines[1].split(",");
    console.log(getResult(issues, answers));
    lines.length = 0;
  }
});
 
function getResult(issues, answers) {
  const ans = [];
 
  for (let issue of issues) {
    const str1 = [...new Set(issue)].sort().join("");
    let find = false;
 
    for (let answer of answers) {
      const str2 = [...new Set(answer)].sort().join("");
      if (str1 === str2) {
        ans.push(answer);
        find = true;
        // break; // 如果一个谜面对应多个谜底，这里就不能break，如果一个谜面只对应一个谜底，那这里就要break，考试的时候都试下
      }
    }
 
    if (!find) {
      ans.push("not found");
    }
  }
 
  return ans.join(",");
}