// 寻找密码  满分

// 解题思路：
// 将输入的密码本放在list中，主要是想用list的contains函数
// 循环求出所有符合密码规则的字符串，取较长的字符串作为密码；如果字符串长度相等，则取字典序大的作为密码

//let pwds = readline().split(" ");
let pwds = "b eredderd bw bww bwwl bwwlm bwwln".split(" ");
 
let ans = "";
let all = new Set();
for (let s of pwds) {
    all.add(s);
}
for (let s of pwds) {
    if (check(s, all)) {
        if (s.length > ans.length) {
            ans = s;
        } else if (s.length == ans.length && s.localeCompare(ans) > 0) {
            ans = s;
        }
    }
}
console.log(ans);
 
function check( s, all) {
    for (let i = 0; i < s.length; i++) {
        if (!all.has(s.substring(0, i + 1))) {
            return false;
        }
    }
    return true;
}