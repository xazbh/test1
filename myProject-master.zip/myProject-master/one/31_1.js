// 优秀学员统计  满分

// 解题思路：
// 使用map对象来统计打卡情况。
// key：员工工号
// value：int[]员工打卡情况
//           int[0]：第一次打开时间
//           int[1]：总打卡数
// 将map转换为list进行排序：
// 天数多的靠前；天数相同的第一次打卡时间在前的靠前

//人数
//let N = Number(readline());
let N = Number("7");
let queue = [];
let day = 0;
//将员工的id、打卡次数和打卡开始时间放入map中
let map = new Map();
//let input = readline();
let test = [
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5",
    "0 1 2 3 4 5"
];
 
while (day <30){
    //let list = readline().split(" ").map(Number);
    let list = test[day].split(" ").map(Number);
    for (let cur of list) {
        if(!map.has(cur)){
            let man = new Man( cur, 0, -1);
            map.set(cur,man);
        }
        let man = map.get(cur);
        man.count = man.count+1;
        man.start = man.start == -1 ? day : man.start;
    }
    day ++;
}
 
map.forEach((v,k) => {
    queue.push(v);
})
 
queue.sort((a,b) => {
    if(a.count == b.count){
        if(a.start == b.start){
            return a.id - b.id;
        }
        return a.start - b.start;
    }
    return b.count - a.count;
})
 
for (let i = 0; i < 5; i++) {
    //取出最前面的员工
    let man = queue.shift();
    console.log(man.id + " ");
    if(queue.length == 0) break;
}
 
function Man( id, count, start){
    this.id = id;
    this.count = count;
    this.start = start;
}