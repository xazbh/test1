//打印机队列 100%
/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
let n;
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 1) {
    n = parseInt(lines[0]);
  }
 
  if (n && lines.length === n + 1) {
    lines.shift();
 
    const tasks = lines.map((line) => line.split(" "));
 
    getResult(tasks);
 
    lines.length = 0;
  }
});
 
function getResult(tasks) {
  const print = {};
 
  let taskId = 1;
  for (let i = 0; i < tasks.length; i++) {
    const [type, printId, priority] = tasks[i];
 
    if (type === "IN") {
      const arr = [taskId, priority, i]; // i 是先来后到的顺序
      if (!print[printId]) {
        print[printId] = []; // 基于数组实现优先队列
      }
      print[printId].push(arr);
      print[printId].sort((a, b) => (a[1] != b[1] ? b[1] - a[1] : a[2] - b[2])); // 维持高优先级在头部，如果优先级相同，则按先来后到
      taskId++;
    } else {
      if (!print[printId] || print[printId].length == 0) {
        console.log("NULL");
      } else {
        const arr = print[printId].shift();
        console.log(arr ? arr[0] : "NULL");
      }
    }
  }
}