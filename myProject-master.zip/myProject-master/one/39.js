// 查找充电设备组合  预计100%

/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 3) {
    const n = lines[0] - 0;
    const p = lines[1].split(" ").map(Number);
    const p_max = lines[2] - 0;
 
    console.log(getResult(n, p, p_max));
    lines.length = 0;
  }
});
 
function getResult(n, p, p_max) {
  const dp = new Array(n + 1).fill(0).map(() => new Array(p_max + 1).fill(0));
 
  for (let i = 0; i <= n; i++) {
    for (let j = 0; j <= p_max; j++) {
      if (i === 0 || j === 0) continue;
 
      // 注意这里p[i-1]中i-1不会越界，因为i=0时不会走到这一步，另外i-1是为了防止尾越界，因为dp矩阵的行数是n+1，因此p[i]可能会尾越界，而p[i-1]就不会越界了
      if (p[i - 1] > j) {
        dp[i][j] = dp[i - 1][j];
      } else {
        dp[i][j] = Math.max(dp[i - 1][j], p[i - 1] + dp[i - 1][j - p[i - 1]]);
      }
    }
  }
 
  return dp[n][p_max];
}