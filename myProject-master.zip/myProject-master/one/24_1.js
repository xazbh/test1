// 找数字  满分
// 解题思路：
// 将二维数组中的值和坐标转化为map对象。
// 遍历二维数组中的值，找出其值的所有坐标，求出其中距离最短的值

// let m = Number(readline());
// let n = Number(readline());
let m = Number("3");
let n = Number("5");
let map = [];
let test = [
            "0 3 5 4 2",
            "2 5 7 8 3",
            "2 5 4 2 4"
        ];
for (let i = 0; i < m; i++) {
    //map[i] = readline().split(" ").map(Number);
    map[i] = test[i].split(" ").map(Number);
}
 
let ans = Array(m).fill(0).map(()=> Array(n).fill(0));
for (let i = 0; i < m; i++) {
    for (let j = 0; j < n; j++) {
        ans[i][j] = find(map, i, j);
    }
}
 
console.log(ans);
 
function find( map, i, j) {
 
    let target = map[i][j];
    let ans = Number.MAX_VALUE;
 
    for (let k = 0; k < map.length; k++) {
        for (let l = 0; l < map[0].length; l++) {
            if (k == i && l == j) {
                continue;
            }
            if (map[k][l] == target) {
                ans = Math.min(ans, Math.abs(i - k) + Math.abs(j - l));
            }
        }
    }
 
    return ans == Number.MAX_VALUE ? -1 : ans;
}