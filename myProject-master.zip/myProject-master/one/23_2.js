// 任务总执行时长  100%  No.70

 
function main(a,b,num) {
    if (a === b) {
        console.log(a*num)
    }
    
    let result = new Set()
    for (let i = 0; i <= num; i++) {
        result.add(a * i + b * (num - i))
    }
    
    console.log([...result].sort((a, b) => a - b))
}
 
 
main(1,2,3)