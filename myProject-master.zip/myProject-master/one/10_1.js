// 满分  货币单位换算
var n = parseInt(readline())
 
const lines = []
while(n--) {
    lines.push(readline())
}
 
lines.forEach((line) => {
    parseLine(line)
})
 
function parseLine(line) {
    const unitMap = {
    'fen': 'CNY',
    'cents': 'HKD',
    'sen': 'JPY',
    'eurocents': 'EUR',
    'pence': 'GBP'
}
    
    const nums = line.split(/[A-Z|a-z]+/).filter(item => item).map(Number)
    const units = line.split(/[0-9]+/).filter(item => item)
    if (nums.length > 1) {
        return [nums[0] * 100 + nums[1], units[0]]
    }
    else if (units[0] > 'A' && units[0][0] < 'Z') {
        // 只有元
        return [nums[0] * 100, units[0]]
    } else {
        // 只有分
        return [nums[0], unitMap[units[0]]]
    }
}
 
// 转换
function trans(num, unit) {
    switch(unit) {
        case 'CNY':
            return num
        case 'JPY':
            return num * 100 / 1825
        case 'HKD':
            return num * 100 / 123
        case 'EUR':
            return num * 100 / 14
        case 'GBP':
            return num * 100 / 12
    }
}
 
console.log(parseInt(lines.reduce((total, line) => { return total + trans(...parseLine(line)) }, 0)))
 
 