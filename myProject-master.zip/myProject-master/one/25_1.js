//整理扑克牌  满分

//let list = readline().split(" ");
let list = "4 4 2 1 2 1 3 3 3 4".split(" ");
 
let temp = [];
for (let i = 0; i < list.length; i++) {
 
    let num = list[i];
 
    let p = temp[num];
    if (p == null) {
        p = new Pair(num, 1);
        temp[num] = p;
    } else {
        p.count++;
    }
}
 
temp.sort((o1, o2) => {
    if (o1 == null) {
        return -1;
    }
    if (o2 == null) {
        return 1;
    }
    if (o2.count == o1.count) {
        return o2.k - o1.k;
    }
    return o2.count - o1.count;
});
let three = [];
let two = [];
let one = [];
for (let aTemp of temp) {
    if (aTemp == null) continue;
    if (aTemp.count > 3) {
        for (let j = 0; j < aTemp.count; j++) {
            console.log((aTemp.k) + " ");
        }
    } else {
        if (aTemp.count == 3) {
            three.push(aTemp);
        } else if (aTemp.count == 2) {
            two.push(aTemp);
        } else if (aTemp.count == 1) {
            one.push(aTemp);
        }
    }
}
 
let res = "";
for (let i = 0; i < three.length; i++) {
    for (let j = 0; j < 3; j++) {
        res += (three[i].k) + " ";
    }
    if (i + 1 == three.length) { // 没有3张了，和2张比
        if (two.length > 0) {
            for (let j = 0; j < 2; j++) {
                res += two[0].k + " ";
            }
            two.splice(0, 1);
        }
    } else {
        if (three[i + 1].k > two[0].k) {
            // 需要拆分
            one.push(new Pair(three[i + 1].k, 1));
            for (let j = 0; j < 2; j++) {
                res += three[i + 1].k + " ";
            }
            i++;
        } else {
            for (let j = 0; j < 2; j++) {
                res += two[0].k + " ";
            }
            two.splice(0, 1);
        }
    }
}
for (let aTwo of two) {
    for (let j = 0; j < 2; j++) {
        res += aTwo.k + " ";
    }
}
one.sort((o1, o2) => {
    if (o2.count == o1.count) {
        return o2.k - o1.k;
    }
    return o2.count - o1.count;
});
for (let anOne of one) {
    res += anOne.k + " ";
}
 
console.log(res.substring(0, res.length - 1))
 
function Pair( k, count) {
    this.k = k;
    this.count = count;
}