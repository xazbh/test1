// 箱子之形摆放  满分

//let strings = readline().split(" ");
let strings = "ABCDEFG 3".split(" ");
 
let box = strings[0];
let n = Number(strings[1]);
 
let map = new Map();
for(let i=0; i<box.length; i++){
 
    let index;    //用索引取余来确定箱子的位置
    if(parseInt(i/n)%2 == 0){     //偶数列为正序，奇数列为倒序
        index = i%n;
    }else {
        index = n - 1 - i%n;
    }
 
    let c = box[i];
    if(map.has(index)){
        map.set( index, map.get(index) + c);
    }else {
        map.set(index, c);
    }
    //map.put(index, map.getOrDefault(index, new StringBuffer()).append(c));
}
 
for(let sb of map.values()){
    console.log(sb);
}