// 日志首次上报最多积分  预计100%


/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
rl.on("line", (line) => {
  const arr = line.split(" ").map(Number);
 
  const dp = [arr[0]]; // dp[i]表示：第i时刻可得的正向分
  const delay = [0]; // delay[i]表示：第i时刻被扣除的负向分
  const score = [arr[0]]; // score[i]表示：第i时刻最终得分
  for (let i = 1; i < arr.length; i++) {
    dp[i] = Math.min(100, dp[i - 1] + arr[i]); // 最多上报100条
    delay[i] = delay[i - 1] + dp[i - 1];
    score[i] = dp[i] - delay[i];
 
    // 达到100条时必须上报，此时完成首次上报，结束循环
    if (dp[i] >= 100) break;
  }
 
  console.log(Math.max.apply(null, score));
});