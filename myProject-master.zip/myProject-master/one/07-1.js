// 满分 对称字符串
var lineNum = parseInt(readline());
for (var i = 1; i <= lineNum; i++) {
    var nk = readline().split(" ");
    var line = parseInt(nk[0]);
    var cur = parseInt(nk[1]);
    // 该行字符数
    var charNum = Math.pow(2, line - 1);
    var re = findChar(charNum, cur);
    if (re % 2 == 0) {
        print("red");
    } else {
        print("blue");
    }
}
 
function findChar(count, cur, re = 0) {
    if (count == 1) {
        return re;
    }
    var half = count / 2;
    if (cur < half) {
        re++;
        return findChar(half, cur, re);
    } else {
        return findChar(half, cur - half, re);
    }
}