// 最小调整顺序次数、特异性双端队列  预计100%


/* JavaScript Node ACM模式 控制台输入获取 */
const readline = require("readline");
 
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
 
const lines = [];
let n;
rl.on("line", (line) => {
  lines.push(line);
 
  if (lines.length === 1) {
    n = parseInt(lines[0]);
  }
 
  if (n && lines.length === 1 + 2 * n) {
    lines.shift();
    console.log(getResult(lines));
    lines.length = 0;
  }
});
 
function getResult(cmds) {
  let size = 0;
  let isSorted = true;
  let count = 0;
 
  for (let i = 0; i < cmds.length; i++) {
    const cmd = cmds[i];
    if (cmd.startsWith("head add")) {
      if (size && isSorted) isSorted = false;
      size++;
    } else if (cmd.startsWith("tail add")) {
      size++;
    } else {
      if (!size) continue;
      if (!isSorted) {
        count++;
        isSorted = true;
      }
      size--;
    }
  }
 
  return count;
}