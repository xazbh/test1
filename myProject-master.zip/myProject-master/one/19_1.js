//寻找链表的中间结点  满分
// 解题思路：
// 主要使用链表；

let [first, count] = readline().split(' ')
count = Number(count)
 
const nodes = []
let i = count
while(i--) {
    nodes.push(readline().split(' '))
}
 
const nodeMap = {}
 
nodes.forEach((node) => {
    const [addr, value, next] = node
    nodeMap[addr] = {
        value,
        next
    }
})
 
// 可能有节点不属于链表, 求链表真实长度
let lineLength = 1
let current = nodeMap[first]
while(current.next !== '-1') {
    current = nodeMap[current.next]
    lineLength++
}
 
let center = Math.floor(lineLength / 2)
 
let currNode = nodeMap[first]
 
while(center--) {
    currNode = nodeMap[currNode.next]
}
 
console.log(currNode.value)
 
 